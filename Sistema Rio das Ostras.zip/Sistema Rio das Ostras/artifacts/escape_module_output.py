﻿from pathlib import Path
import re
for mod in ['social','bi']:
 p=Path(f'static/{mod}-ui.js');s=p.read_text(encoding='utf-8')
 s=re.sub(r'\$\{((?!this\.)[a-z]\w*(?:\.[a-zA-Z_]\w*)+)\}',r'${ModulesUI.escape(\1)}',s)
 p.write_text(s,encoding='utf-8')
p=Path('artifacts/ui-revisao-20260924/browser_check.py');s=p.read_text(encoding='utf-8').replace("'head_name':'Família de teste'","'head_name':'Família de teste <b>literal</b>'")
s=s.replace("            page.locator('#social-family-search').fill", "            assert page.locator('#social-tab-content b').count()==0\n            assert '<b>literal</b>' in page.locator('#social-tab-content').inner_text()\n            page.locator('#social-family-search').fill")
p.write_text(s,encoding='utf-8')
