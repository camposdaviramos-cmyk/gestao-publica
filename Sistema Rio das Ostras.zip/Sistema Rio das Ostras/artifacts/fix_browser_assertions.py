﻿from pathlib import Path
p=Path('artifacts/ui-revisao-20260924/browser_check.py');s=p.read_text(encoding='utf-8').replace('page.wait_for_function("document.', 'page.wait_for_function("() => document.').replace("{'ap-title':'Plano de teste UI'", "{'ap-ref':'UI-001','ap-title':'Plano de teste UI'");p.write_text(s,encoding='utf-8')
