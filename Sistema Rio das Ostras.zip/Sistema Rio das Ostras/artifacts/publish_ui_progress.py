﻿from pathlib import Path
import json,datetime
p=Path('docs/anexo-iii-conformidade.json');d=json.loads(p.read_text(encoding='utf-8'))
updated=datetime.datetime.now(datetime.timezone.utc).isoformat(timespec='seconds')
resolutions={
'AUD-001':('Parcial','Painel do Anexo corrigido: sem crédito parcial, situação Não comprovado explícita e totais por área. A homologação da POC permanece pendente.'),
'AUD-002':('Corrigido no escopo de interface','154 manipuladores inline substituídos por ações explícitas compatíveis com CSP. Navegação nas 33 abas e fluxos de gravação validados no Chromium sem violações CSP e sem erros JavaScript.'),
'AUD-003':('Parcial','Decorador financeiro exige write nas mutações e read nas consultas; teste negativo confirma 403 para leitor. Segregação por entidade, dupla custódia e autoria integral ainda exigem validação.'),
'AUD-004':('Parcial','Todas as rotas privadas do blueprint Pessoas exigem permissão de leitura no módulo. Testes negativos cobrem cadastro, cargos, locais e SST. Restrições por titular, lotação e entidade continuam pendentes.'),
'AUD-005':('Não implementado','A tela deixou de acionar a autenticação fictícia por CPF e de declarar termo assinado. Informa a pendência e identifica o operador da sessão. O mecanismo completo de autenticação/assinatura SIAFIC continua pendente.'),
'AUD-029':('Parcial','Consulta de atualizações pendentes corrigida para people_employees; testada com pedido real e matrícula/nome associados. Regras de titularidade, recuperação e comprovantes permanecem abertas.'),
'AUD-046':('Corrigido no escopo de interface','Financeiro, Pessoas, Social e BI usam o cliente api autenticado, como Controle já fazia. CSRF e resposta HTTP são tratados antes do sucesso. Salvamentos e rejeição de conta contábil inválida verificados pela interface.')}
for finding in d['audit']['finding_details']:
 if finding['id'] in resolutions:
  status,details=resolutions[finding['id']]
  finding.setdefault('initial_audit_status',finding['status'])
  finding['status']=status
  finding['remediation']={'updated_at':updated,'status':status,'details':details,'evidence':['tests/test_module_ui_regressions.py','artifacts/ui-revisao-20260924/browser.json','artifacts/ui-revisao-20260924/tests.xml','artifacts/ui-revisao-20260924/finance-final.xml']}
modules={
'finance':('Abas, formulários, notas fiscais, cheques, escrituração, exportações e adiantamentos; prestação de contas usa registro real e confere os valores.','Cálculos oficiais, integração bancária, Reinf/SIAFIC e homologação: ver AUD-005 e AUD-007 a AUD-014.'),
'control':('Abas, calendário, alertas, regras e planos de ação com eventos CSP; cadastro de plano testado.','Entrega de e-mails, regras oficiais e conectores externos: AUD-036 a AUD-038.'),
'people':('Abas, cópia de servidor, substituição, reintegração, detalhes, fila do portal, CAT, PPP e catálogo de EPIs conectados; CSRF e leitura do módulo protegidos.','Titularidade, regras previdenciárias e integrações eSocial/portal: AUD-004, AUD-006, AUD-026 a AUD-029.'),
'social':('Abas, busca por Enter, prontuário e formulários padronizados; cadastro de família com persistência validado.','RMA oficial, assinatura, sigilo especializado e integrações: AUD-030 a AUD-035.'),
'bi':('Abas, exercício, consulta por Enter, compartilhamento e modo TV corrigidos; saída por Esc e limpeza ao mudar de página.','Origem dos indicadores e cálculos ainda precisam de validação; AUD-039 permanece aberto.')}
for item in d['items']:
 ids=set(item.get('audit',{}).get('findings',[])+item.get('audit',{}).get('transversal_findings',[]))
 relevant=sorted(ids & resolutions.keys())
 if item['module'] in modules or relevant:
  lines=['ATUALIZAÇÃO DAS CORREÇÕES — '+updated]
  if item['module'] in modules:lines.append('Interface do módulo: design global, navegação e formulários corrigidos; ver painel de andamento. Isto não comprova o aceite integral deste requisito.')
  lines.extend(code+' | '+resolutions[code][0]+' | '+resolutions[code][1] for code in relevant)
  item['coverage']='\n'.join(lines)+'\n\nHISTÓRICO DA AUDITORIA INICIAL (anterior a estas correções):\n'+item['coverage']
  item['audit']['remediation']={'updated_at':updated,'verified_scope':'Interface e controles; sem alterar aceite integral do requisito','findings':relevant}
d['audit']['ui_remediation']={'status':'Interface entregue e verificada; conformidade integral pendente','updated_at':updated,'modules':list(modules),'items':[{'module':mod,'status':'Interface corrigida e testada','completed':v[0],'pending':v[1]} for mod,v in modules.items()], 'tests':{'unique_pytest_tests_passed':57,'tabs_tested':33,'inline_handlers_replaced':154,'browser_csp_violations':0,'javascript_errors':0,'viewports':[1440,390],'themes':['light','dark'],'evidence':'artifacts/ui-revisao-20260924/browser.json'}}
d['note']='ATUALIZAÇÃO 24/09/2026: design e controles de finance, control, people, social e bi corrigidos no escopo de interface e verificados. Consulte o painel de andamento abaixo e os registros AUD-002/AUD-046. Foram mantidos os 1.314 requisitos e o histórico da auditoria; funcionalidades oficiais, integrações, infraestrutura e homologação ainda têm pendências. O percentual considera apenas itens registrados como Implementado, sem crédito parcial; não equivale à aprovação da POC. Os requisitos completos não foram promovidos automaticamente pelo conserto da interface.'
p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
report='''# Correções prioritárias de interface — 24/09/2026

Escopo: finance, control, people, social e bi. A entrega não comprova conformidade integral com o Edital ou o Anexo III.

- Cabeçalhos, abas, botões, tabelas, formulários e temas usam os tokens do sistema. Tabelas extensas rolam dentro do painel em telas menores.
- 154 eventos inline foram substituídos por um registro explícito de ações, sem eval e sem relaxar a CSP.
- Cliente autenticado comum: CSRF nas gravações, verificação de resposta HTTP, tratamento de erros e proteção contra cliques repetidos.
- Funções ausentes foram conectadas a formulários e consultas existentes: cópia/substituição/reintegração, detalhes, CAT/PPP/EPIs, pendências cadastrais, nota fiscal, cheque e adiantamento.
- Cadastros sociais deixam de inserir nomes, documentos, pareceres e responsáveis fictícios provenientes dos antigos prompts.
- Adiantamentos são lidos do banco e a prestação de contas usa o ID da linha. Os valores devem totalizar o adiantamento, sem registrar prestação duplicada ou de ID inexistente.
- BI: Enter no assistente, compartilhamento em modal, projeção por configuração dos painéis, saída por Esc e encerramento ao navegar.
- Leitores financeiros não podem gravar; consultas privadas de Pessoas requerem acesso ao módulo. A fila de atualizações do portal usa a tabela correta.
- A tela SIAFIC informa a pendência AUD-005, em vez de declarar autenticação e assinatura inexistentes.
- Anexo III: painel de progresso por módulo, histórico preservado e percentual sem crédito parcial, incluindo Não comprovado.

## Verificação

57 testes pytest distintos passaram nas suítes selecionadas e regressões finais (relatórios tests.xml e finance-final.xml). Os relatórios se sobrepõem e não devem ter suas contagens somadas.

Chromium em instalação temporária: 33 abas, 5 módulos, 1440 px e 390 px, temas claro/escuro; sem erros JavaScript ou violações CSP. Fluxos positivos: escrituração, nota fiscal, cheque, adiantamento/prestação de contas, cópia de servidor, cadastro familiar, plano de ação, compartilhamento, assistente por Enter e TV. Fluxo negativo: conta contábil inválida conserva o formulário e apresenta o erro retornado. Um HTTP 400 no log é esperado por esse teste negativo.

Evidências: artifacts/ui-revisao-20260924/browser.json, screenshots, tests.xml, finance-final.xml; script reproduzível browser_check.py. Testes não criam dados na instalação operacional.

## Pendências preservadas

AUD-002 e AUD-046 têm correção verificada no escopo de interface. AUD-001, AUD-003, AUD-004 e AUD-029 receberam correções parciais. Os cálculos demonstrativos, simulações de integrações externas, titularidade, assinatura, nuvem e demais pendências documentadas não foram convertidos em conformidade integral. Cada requisito mantém seu status de aceite; a evolução desta entrega está separada no painel da página annex.
'''
Path('docs/CORRECOES-INTERFACE-2026-09-24.md').write_text(report,encoding='utf-8')
print('Updated audit findings and',len(d['audit']['ui_remediation']['items']),'module delivery statuses; preserved',len(d['items']),'requirements')
