﻿from pathlib import Path
p=Path('static/module-ui.js');s=p.read_text(encoding='utf-8');start=s.index('      const values =');end=s.index('        const data = await save(values);',start);s=s[:start]+'''      submit.disabled = true;
      form.querySelector('.form-error').textContent = '';
      try {
        const values = Object.fromEntries(new FormData(form));
        for (const [name, , type] of fields) {
          if (type === 'number') values[name] = Number(values[name]);
          if (type === 'file') values[name] = await form.elements[name].files[0]?.text() || '';
        }
'''+s[end:];p.write_text(s,encoding='utf-8')
p=Path('static/finance-ui.js');s=p.read_text(encoding='utf-8').replace("if (this.currentTab === 'tesouraria') this.loadAdvanceFunds();", "if (this.currentTab === 'tesouraria') return this.loadAdvanceFunds();").replace('      this.loadJournalEntries();','      return this.loadJournalEntries();');p.write_text(s,encoding='utf-8')
p=Path('artifacts/ui-revisao-20260924/browser_check.py');s=p.read_text(encoding='utf-8');s=s.replace("                page.screenshot(path=str(OUT/f'{route}-dark.png'),full_page=True)", "                page.wait_for_timeout(350)\n                page.screenshot(path=str(OUT/f'{route}-dark.png'),full_page=True)")
s=s.replace("            assert page.evaluate('annexState.items.length')==1314", """            assert page.evaluate('annexState.items.length')==1314
            assert page.locator('#annex-remediation tbody tr').count()==5
            assert page.evaluate("annexStats([{status:'Parcial'},{status:'Implementado'},{status:'Não comprovado'}]).pct")==33.3
            assert page.evaluate("annexStats([{status:'Não comprovado'}]).unverified")==1
            assert '50% Parcial' not in page.locator('#main').inner_text()""")
s=s.replace("            visit('control')", """            page.locator('.social-tab-btn[data-tab="acolhimento"]').click()
            page.get_by_role('button',name='Admissão em Acolhimento',exact=True).click()
            fill_form({'unit_id':6,'resident_name':'Residente UI','reason':'Teste de acolhimento','responsible_technician':'Técnico UI'})
            submit('/social/shelterings')
            row=page.locator('tr').filter(has_text='Residente UI')
            row.get_by_role('button',name='Desligar',exact=True).click()
            fill_form({'discharge_date':'2026-09-24','discharge_reason':'Reintegração familiar'})
            submit('/discharge')
            visit('control')""")
p.write_text(s,encoding='utf-8')
