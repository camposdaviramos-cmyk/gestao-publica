﻿import json
from pathlib import Path
d=json.loads(Path('docs/anexo-iii-conformidade.json').read_text(encoding='utf-8'))
i=next(i for i in d['items'] if i['module']=='finance')
print(i['coverage'][:2400]);print(i['audit'])
