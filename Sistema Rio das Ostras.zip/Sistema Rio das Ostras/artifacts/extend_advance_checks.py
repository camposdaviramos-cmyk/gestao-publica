﻿from pathlib import Path
p=Path('tests/test_module_ui_regressions.py');s=p.read_text(encoding='utf-8')+'''

def test_advance_controls_use_real_rows_and_validate_accountability(admin):
    client, headers = admin
    created = client.post('/api/finance/treasury/advance-funds', json={
        'server_cpf': '52998224725', 'server_name': 'Responsável do teste',
        'commitment_id': 'TESTE-001', 'amount_cents': 10000
    }, headers=headers)
    assert created.status_code == 201
    fund_id = created.json['id']
    rows = client.get('/api/finance/treasury/advance-funds').json
    assert rows[0]['id'] == fund_id
    assert rows[0]['amount_cents'] == 10000
    path = '/api/finance/treasury/advance-funds/accountability'
    data = {'fund_id': fund_id, 'spent_cents': 8000, 'returned_cents': 1000}
    assert client.post(path, json=data, headers=headers).status_code == 400
    assert client.get('/api/finance/treasury/advance-funds').json[0]['status'] == 'Aberto'
    data['returned_cents'] = 2000
    assert client.post(path, json=data, headers=headers).status_code == 200
    assert client.post(path, json=data, headers=headers).status_code == 409
    data['fund_id'] = 99999
    assert client.post(path, json=data, headers=headers).status_code == 404
''';p.write_text(s,encoding='utf-8')
p=Path('artifacts/ui-revisao-20260924/browser_check.py');s=p.read_text(encoding='utf-8');s=s.replace("                entry['csp']=", "                page.evaluate(\"document.documentElement.dataset.theme='dark'\")\n                page.screenshot(path=str(OUT/f'{route}-dark.png'),full_page=True)\n                page.evaluate(\"document.documentElement.dataset.theme='light'\")\n                entry['csp']=")
s=s.replace("            visit('people')", """            page.get_by_role('button',name='+ Conceder Adiantamento',exact=True).click()
            fill_form({'server_cpf':'52998224725','server_name':'Responsável UI','commitment_id':'UI-001','amount':'100','advance_type':'Suprimento_Fundos'})
            submit('/finance/treasury/advance-funds')
            page.get_by_role('button',name='Prestar Contas',exact=True).first.click()
            fill_form({'spent':80,'returned':20})
            submit('/finance/treasury/advance-funds/accountability')
            assert 'Prestado' in page.locator('#finance-advance-body').inner_text()
            visit('people')""")
s=s.replace("            result['final_csp']=", """            page.goto(base + '/#/annex')
            page.wait_for_selector('.erp-requirement')
            assert page.evaluate('annexState.items.length')==1314
            result['annex_items']=1314
            page.locator('#erp-annex-search').fill('AUD-002')
            page.wait_for_timeout(150)
            page.screenshot(path=str(OUT/'annex-progress.png'),full_page=True)
            result['final_csp']=""")
p.write_text(s,encoding='utf-8')
