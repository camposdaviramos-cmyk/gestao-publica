﻿from pathlib import Path
p=Path('static/module-forms.js');s=p.read_text(encoding='utf-8');needle='  FinanceUI.viewReport ='
insert='''  FinanceUI.generateObeBatch = () => postForm('Gerar lote de ordem bancária','/finance/treasury/obe/generate',[
    id('contract_id','Código do contrato'),F('commitment_ids','Códigos dos empenhos (separados por vírgula)'),F('payment_method','Forma de pagamento','text','OBE')
  ],null,d => {
    const ids=d.commitment_ids.split(',').map(value => Number(value.trim()));
    if (!ids.length || ids.some(value => !Number.isInteger(value) || value<=0)) throw new Error('Informe códigos de empenhos inteiros e positivos.');
    return {...d,commitment_ids:ids};
  });
  FinanceUI.simulateBankReturn = () => postForm('Importar retorno bancário','/finance/treasury/obe/return',[
    id('order_id','Código da ordem bancária'),F('return_content','Arquivo de retorno','file')
  ]);
  FinanceUI.simulateOfxImport = () => postForm('Importar extrato OFX','/finance/treasury/ofx/import',[
    F('bank_account_id','Conta bancária'),F('ofx_content','Arquivo OFX','file')
  ]);
  FinanceUI.runAutoReconcile = () => postForm('Conciliar extrato','/finance/treasury/ofx/reconcile',[id('reconciliation_id','Código da conciliação')]);
  FinanceUI.lockCalendar = () => postForm('Bloquear período de conciliação','/finance/treasury/ofx/lock',[
    id('exercise','Exercício'),id('month','Mês'),F('reason','Justificativa','textarea')
  ]);
  FinanceUI.transmitReinfEvent = eventType => postForm('Processar evento EFD-Reinf','/finance/reinf/events/transmit',[
    F('event_type','Evento','text',eventType),F('competence','Competência','month'),id('taxpayer_id','Código do contribuinte')
  ],d => show('Resultado do processamento EFD-Reinf',d));
'''
s=s.replace(needle,insert+needle);p.write_text(s,encoding='utf-8')
p=Path('static/module-ui.js');s=p.read_text(encoding='utf-8');s=s.replace("for (const [name, , type] of fields) if (type === 'number') values[name] = Number(values[name]);", "for (const [name, , type] of fields) {\n        if (type === 'number') values[name] = Number(values[name]);\n        if (type === 'file') values[name] = await form.elements[name].files[0]?.text() || '';\n      }");s=s.replace("form.querySelector('.form-error').textContent = error.message;", "if (form.isConnected && document.getElementById('modal').open) form.querySelector('.form-error').textContent = error.message;\n        else toast(error.message, true);")
p.write_text(s,encoding='utf-8')
# Escape values that are displayed in finance rows and assistant results.
p=Path('static/finance-ui.js');s=p.read_text(encoding='utf-8');
for field in ['entry_date','fact_type','debit_account','credit_account']:
 s=s.replace('${r.'+field+'}', '${ModulesUI.escape(r.'+field+')}')
p.write_text(s,encoding='utf-8')
p=Path('static/bi-ui.js');s=p.read_text(encoding='utf-8').replace('${data.answer}','${ModulesUI.escape(data.answer)}').replace('${data.domain || \'ANALÍTICO\'}',"${ModulesUI.escape(data.domain || 'ANALÍTICO')}").replace('${JSON.stringify(data.data, null, 2)}','${ModulesUI.escape(JSON.stringify(data.data, null, 2))}');p.write_text(s,encoding='utf-8')
p=Path('people_api.py');s=p.read_text(encoding='utf-8');needle="people_bp = Blueprint('people_api', __name__)";s=s.replace(needle,needle+"\n\n@people_bp.before_request\ndef authorize_people_module():\n    if not request.path.startswith('/api/public/'):\n        require('people', 'read')\n");p.write_text(s,encoding='utf-8')
