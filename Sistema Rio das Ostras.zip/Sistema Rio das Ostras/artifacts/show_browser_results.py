﻿import json
from pathlib import Path
r=json.loads(Path('artifacts/ui-revisao-20260924/browser.json').read_text(encoding='utf-8'))
for x in r['routes']:print(x['route'],len(x['tabs']),x['mobile_width'],all(t['active'] for t in x['tabs']))
