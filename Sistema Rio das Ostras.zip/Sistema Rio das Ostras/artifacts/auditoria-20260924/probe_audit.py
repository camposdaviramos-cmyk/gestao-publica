"""Reproduções de auditoria exclusivamente em instalação descartável."""
import json
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from app import create_app
from db import get_db

results = []
def record(name, expected, actual, violates):
    results.append(dict(check=name, expected=expected, actual=actual, finding_confirmed=bool(violates)))

with tempfile.TemporaryDirectory(prefix='rio-audit-') as td:
    app = create_app({'TESTING': True, 'DATA_DIR': td, 'DATABASE': str(Path(td) / 'audit.db')})
    admin = app.test_client()
    password = 'AuditoriaTemporaria2026!!'
    assert admin.post('/api/setup', json={'name': 'Auditoria temporária', 'email': 'audit@example.test', 'password': password, 'demo': False}).status_code == 201
    login = admin.post('/api/login', json={'email': 'audit@example.test', 'password': password})
    headers = {'X-CSRF-Token': login.json['csrf']}
    for email, perms in [('none@example.test', {}), ('read@example.test', {'finance': ['read']})]:
        with app.app_context():
            db = get_db()
            scopes = json.loads(db.execute('SELECT permissions FROM groups WHERE id=1').fetchone()[0])
            restricted = {key: [] for key in scopes}
            restricted.update(perms)
        response = admin.post('/api/users', json={'name': 'Conta de auditoria', 'email': email, 'password': password, 'group_id': 3, 'force_password': False, 'permissions': restricted}, headers=headers)
        assert response.status_code == 200, response.json
    client = app.test_client()
    login = client.post('/api/login', json={'email': 'none@example.test', 'password': password})
    no_headers = {'X-CSRF-Token': login.json['csrf']}
    for route in ['/api/people/employees', '/api/people/positions', '/api/people/sst/monitors']:
        response = client.get(route)
        record('Sem permissão: ' + route, '403', {'status': response.status_code, 'keys': list(response.json) if isinstance(response.json, dict) else None}, response.status_code == 200)
    reader = app.test_client()
    login = reader.post('/api/login', json={'email': 'read@example.test', 'password': password})
    read_headers = {'X-CSRF-Token': login.json['csrf']}
    response = reader.post('/api/finance/rules', json={'fact_type': 'AUDIT_ONLY', 'group_name': 'AUDIT', 'rule_name': 'Teste sem escrita', 'debit_account_code': '1.1', 'credit_account_code': '2.1'}, headers=read_headers)
    record('Leitor financeiro cria regra', '403 e nenhuma gravação', {'status': response.status_code, 'response': response.json}, response.status_code == 201)
    public = app.test_client()
    response = public.get('/api/public/people/verify-payslip?token=INVALIDO&emp=999999&comp=1900-01')
    record('Contracheque com token inventado', 'Rejeitar token e documento inexistentes', response.json, response.json.get('autentico') is True)
    response = public.post('/api/public/finance/siafic/auth', json={'cpf': '000', 'name': 'Auditoria fictícia'})
    record('Autenticação SIAFIC sem prova de identidade', 'Rejeitar CPF inválido e não aceitar termo automaticamente', {'status': response.status_code, 'response': response.json}, response.status_code == 200)
    with app.app_context():
        import finance_core as finance
        from cloud_core import init_cloud_db, verify_backup_integrity, get_cloud_infrastructure_status
        from auction_core import init_auction_db, configure_platform, prepare_exchange_package, transmit_exchange_package
        from bi_core import get_executive_lrf_dashboard
        db = get_db()
        entries = db.execute('SELECT count(*) FROM finance_journal_entries').fetchone()[0]
        report = finance.generate_anexo12_balanco_orcamentario(2099)
        record('Balanço de exercício sem movimentos', 'Sem movimentos implica valores zerados/ausentes', {'journal_entries': entries, 'exercise': 2099, 'report': report}, entries == 0 and report['quadro_receitas']['receitas_realizadas'] != 0)
        response = finance.import_msc_file(2026, 1, 'XBRL', 'AUDIT', 'texto inválido matrizSaldosContabeis sem XML')
        record('Importação MSC de texto que não é XML', 'REJECTED', response, response['status'] == 'VALIDATED')
        init_cloud_db()
        clouds = get_cloud_infrastructure_status()
        cloud_backup = verify_backup_integrity(1)
        record('Nuvem e backup em banco recém-criado', 'Sem comprovação sem provedor nem arquivo real', {'sla': clouds['service_level_agreement'], 'backup': cloud_backup}, cloud_backup['integrity_status'] == 'VERIFICADO_OK')
        init_auction_db()
        marker = 'MARCADOR-FICTICIO-AUDITORIA'
        configure_platform('BLL', 'https://invalid.example.test', 'audit', marker)
        stored = db.execute("SELECT client_token_enc FROM auction_platform_configs WHERE provider='BLL'").fetchone()[0]
        record('Credencial do pregão em repouso', 'Criptografada', {'plaintext_equals_input': stored == marker}, stored == marker)
        pack = prepare_exchange_package('AUDIT', 'BLL', [{'item_num': 1, 'description': 'Teste'}])
        sent = transmit_exchange_package(pack['exchange_id'], simulate=False)
        record('Pregão transmitido sem transporte', 'Sem recibo de envio real para endpoint inválido', sent, sent['status'] == 'TRANSMITIDO')
        dash = get_executive_lrf_dashboard(2099)
        record('BI em exercício sem movimentos', 'Valores ausentes/zero e origem explícita', dash, True)
    # Guarda a resposta efetivamente entregue à página na instalação isolada.
    response = admin.get('/api/erp/annex')
    record('Matriz consumida por annex', 'Arquivo disponível e JSON válido', {'status': response.status_code, 'items': len(response.json['items'])}, False)

(Path(__file__).parent / 'probes.json').write_text(json.dumps(results, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps([{'check': r['check'], 'finding_confirmed': r['finding_confirmed']} for r in results], ensure_ascii=False, indent=2))
