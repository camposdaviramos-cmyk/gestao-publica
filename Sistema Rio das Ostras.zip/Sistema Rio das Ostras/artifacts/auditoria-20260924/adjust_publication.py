from pathlib import Path
p=Path('artifacts/auditoria-20260924/publish_audit.py')
s=p.read_text(encoding='utf-8')
s=s.replace('ou selecione a área Edital para as cláusulas.', 'ou EDITAL para as cláusulas, registradas nos campos de cobertura dos requisitos relacionados.')
s=s.replace('não contempla todas as situações da auditoria e inclui aqui registros documentais adicionais.', 'não contempla todas as situações da auditoria.')
anchor='new=dict(old)'
insert="""
# Mantém os 1.314 registros originais; complementos no campo já pesquisável.
by_id = {x['key']: x for x in audited}
for f in findings:
    if not f['requirements']:
        by_id['general.1']['coverage'] += '\\n\\nACHADO TRANSVERSAL DA AUDITORIA (não integra o texto deste requisito):\\n' + finding_text(f)
general_map = {36:2,37:4,38:6,39:7,40:8,41:3,42:9,43:9,44:10,45:5,46:11,47:12,48:13,49:15,50:16,51:17,52:18}
for clause, original in zip(edital_rows, edital['items']):
    n = int(original['id'].split('.')[1])
    target = ('general.'+str(general_map[n])) if n in general_map else ('cloud.1' if n==53 else 'general.4' if n<=8 else 'general.18' if 10<=n<=18 else 'general.16' if 23<=n<=32 or n==9 else 'general.11' if 19<=n<=22 or 54<=n<=66 else 'general.1')
    by_id[target]['coverage'] += f'\\n\\nEDITAL — {original["id"]}, página {original["page"]} — {clause["status"]}\\nTexto da cláusula: {clause["text"]}\\n{clause["coverage"]}'
new=dict(old)
"""
assert anchor in s
s=s.replace(anchor,insert)
s=s.replace('items=[summary_row]+finding_rows+audited+edital_rows,','items=audited,')
s=s.replace("'sources':sources,'annex_items':len(audited)", "'finding_details':findings,'edital_details':edital_rows,'sources':sources,'annex_items':len(audited)")
p.write_text(s,encoding='utf-8')
