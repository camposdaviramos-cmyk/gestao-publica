"""Coleta evidências da auditoria sem modificar código nem banco de operação."""
import ast
import hashlib
import json
import re
import sys
from pathlib import Path
from collections import Counter
from pypdf import PdfReader

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).parent
sys.path.insert(0, str(ROOT))

def save(name, data):
    (OUT / name).write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')

def collect():
    sources = {}
    for name in ['anexo-iii-conformidade.json', 'requisitos.json', 'anexo-iii-itens.json']:
        data = json.loads((ROOT / 'docs' / name).read_text(encoding='utf-8'))
        save('original-' + name, data)
    for pdf in ROOT.glob('*.pdf'):
        pages = [p.extract_text() for p in PdfReader(pdf).pages]
        sources[pdf.name] = {'sha256': hashlib.sha256(pdf.read_bytes()).hexdigest(), 'pages': len(pages)}
        save('pdf-' + ('anexo' if pdf.name == 'ANEXO III.pdf' else 'edital') + '.json', pages)
    files = {}
    routes = []
    for p in sorted(ROOT.rglob('*')):
        if not p.is_file() or any(x in p.parts for x in ['data', '__pycache__', '.git', '.pytest_cache', 'scratch', 'artifacts']):
            continue
        if p.suffix not in ['.py', '.js', '.sql', '.css', '.html', '.json', '.md', '.txt']:
            continue
        rel = p.relative_to(ROOT).as_posix()
        files[rel] = {'sha256': hashlib.sha256(p.read_bytes()).hexdigest(), 'bytes': p.stat().st_size}
        if p.suffix == '.py':
            try:
                tree = ast.parse(p.read_text(encoding='utf-8-sig'))
            except SyntaxError as exc:
                files[rel]['parse_error'] = str(exc)
                continue
            for node in ast.walk(tree):
                if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    continue
                ds = [ast.unparse(d) for d in node.decorator_list]
                if any(re.search(r'\.(get|post|put|delete|route|patch)\(', d) for d in ds):
                    calls = [ast.unparse(n) for n in ast.walk(node) if isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id in ['require', 'entity_access', 'audit']]
                    routes.append({'file': rel, 'line': node.lineno, 'function': node.name, 'decorators': ds, 'checks': calls})
    save('sources.json', sources)
    save('file-manifest-before.json', files)
    save('routes.json', routes)
    print(json.dumps({'sources': sources, 'files': len(files), 'routes': len(routes)}, ensure_ascii=False))

if __name__ == '__main__':
    collect()
