"""Navegação real em instalação temporária. A instalação 8080 só recebe GET público."""
import json
import sys
import tempfile
import threading
from pathlib import Path
from urllib.request import urlopen
from werkzeug.serving import make_server
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).parent
sys.path.insert(0, str(ROOT))
from app import create_app

result = {'routes': [], 'errors': [], 'console_errors': []}
try:
    with urlopen('http://127.0.0.1:8080/api/status', timeout=5) as response:
        result['active_public_status'] = json.load(response)
except Exception as exc:
    result['active_public_status'] = str(exc)

with tempfile.TemporaryDirectory(prefix='rio-audit-browser-') as td:
    app = create_app({'TESTING': True, 'DATA_DIR': td, 'DATABASE': str(Path(td) / 'audit.db')})
    server = make_server('127.0.0.1', 0, app, threaded=True)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    base = f'http://127.0.0.1:{server.server_port}'
    try:
        with sync_playwright() as p:
            browser = p.chromium.launch()
            context = browser.new_context(viewport={'width': 1440, 'height': 1000})
            password = 'AuditoriaTemporaria2026!!'
            assert context.request.post(base + '/api/setup', data={'name': 'Auditoria temporária', 'email': 'audit@example.test', 'password': password}).status == 201
            assert context.request.post(base + '/api/login', data={'email': 'audit@example.test', 'password': password}).status == 200
            page = context.new_page()
            page.on('pageerror', lambda error: result['errors'].append(str(error)))
            page.on('console', lambda message: result['console_errors'].append(message.text) if message.type == 'error' else None)
            page.add_init_script("window.auditViolations=[];document.addEventListener('securitypolicyviolation',e=>window.auditViolations.push({directive:e.violatedDirective,blocked:e.blockedURI}));")
            for route in ['annex', 'finance', 'people', 'social', 'bi', 'control', 'inventory', 'assets', 'fleet', 'works', 'procurement']:
                page.goto(base + '/#/' + route)
                page.wait_for_timeout(1000)
                entry = {'route': route, 'title': page.locator('h1').all_text_contents(), 'inline_controls': page.locator('[onclick]').count()}
                if route in ['finance', 'social', 'bi']:
                    obj = {'finance': 'FinanceUI', 'social': 'SocialUI', 'bi': 'BiUI'}[route]
                    entry['before_tab'] = page.evaluate(f'window.{obj}?.currentTab')
                    buttons = page.locator(f'.{route}-tab-btn')
                    if buttons.count() > 1:
                        buttons.nth(1).click()
                        page.wait_for_timeout(200)
                    entry['after_tab'] = page.evaluate(f'window.{obj}?.currentTab')
                entry['csp_violations'] = page.evaluate('window.auditViolations')
                result['routes'].append(entry)
                if route == 'annex':
                    page.wait_for_selector('.erp-requirement')
                    result['annex_items'] = page.evaluate('annexState.items.length')
                    search = page.locator('#erp-annex-search')
                    search.fill('AUD-001')
                    page.wait_for_timeout(100)
                    result['audit_search_matches'] = page.locator('.erp-requirement').count()
                    page.screenshot(path=str(OUT / 'annex-auditoria.png'), full_page=True)
                    search.fill('')
            browser.close()
    finally:
        server.shutdown()
(OUT / 'browser.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(result, ensure_ascii=False, indent=2))
