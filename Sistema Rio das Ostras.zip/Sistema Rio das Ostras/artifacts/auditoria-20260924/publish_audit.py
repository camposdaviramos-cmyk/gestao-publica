"""Publica somente o conteúdo documental de auditoria consumido por /api/erp/annex.

Não altera APIs, interface, regras de negócio, testes existentes ou banco ativo.
Usa a cópia anterior preservada: executar novamente não duplica registros.
"""
import ast
import json
import re
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).parent
read = lambda path: json.loads(path.read_text(encoding='utf-8'))
old = read(OUT / 'original-anexo-iii-conformidade.json')
edital = read(OUT / 'original-requisitos.json')
catalog = read(OUT / 'original-anexo-iii-itens.json')
sources = read(OUT / 'sources.json')
probes = read(OUT / 'probes.json')
browser = read(OUT / 'browser.json')
annex_pages = read(OUT / 'pdf-anexo.json')
edital_pages = read(OUT / 'pdf-edital.json')
findings = []

def keys(module, *numbers):
    return [f'{module}.{n}' for group in numbers for n in (group if isinstance(group, range) else [group])]

def evidence(file, symbol=None):
    path = ROOT / file
    assert path.exists(), file
    lines = path.read_text(encoding='utf-8-sig').splitlines()
    if symbol:
        matches = [i for i, line in enumerate(lines, 1) if re.search(r'\bdef\s+' + re.escape(symbol) + r'\b', line)]
        if not matches:
            matches = [i for i, line in enumerate(lines, 1) if symbol in line]
        assert matches, (file, symbol)
        return f'{file}:{matches[0]} ({symbol})'
    return file

def add(id, severity, title, requirements, observation, action, acceptance, refs, status='Parcial', clauses=()):
    assert not any(f['id'] == id for f in findings)
    findings.append(dict(id=id, severity=severity, title=title, requirements=requirements,
        clauses=list(clauses), observation=observation, action=action, acceptance=acceptance,
        evidence=refs, status=status))

add('AUD-001', 'Crítica', 'Declaração de 100% sem sustentação e indicador incompatível com a POC', [],
    'A matriz anterior classificava 1.314/1.314 como Implementado. Scripts de atualização promovem faixas inteiras sem verificar os subitens; há referências sem relação com o requisito (ex.: cloud.2 cita SLA em vez das nove certificações). A tela soma Implementado + 50% de Parcial. Os itens 4.77, 4.79.2, 4.80.1 e 4.80.2 exigem avaliação individual e integral de cada item, 90% por módulo e 100% em nuvem.',
    'Substituir futuramente os geradores que promovem requisitos automaticamente por evidências de aceitação por item; adequar o indicador à regra documental, sem crédito para subitem incompleto. Esta auditoria apenas registra a pendência; o cálculo da interface foi preservado.',
    'Vincular cada resultado a roteiro executado, evidência e todos os subitens. Calcular por categoria, sem misturar obrigações do edital e achados de auditoria no denominador.',
    [evidence('tools/update_final_compliance.py'), evidence('tools/update_finance_compliance.py'), evidence('tools/update_social_compliance.py'), evidence('static/annex-ui.js', 'function annexStats')], clauses=['4.56.1','4.77','4.79.2','4.80.1','4.80.2','4.81.5'])
add('AUD-002', 'Crítica', 'Ações das telas bloqueadas pela política CSP', [],
    'Chromium: clicar nas abas de Finanças, Social e BI mantém a aba anterior e gera violação script-src-attr. Há controles onclick também em Pessoas e Controle Interno. O servidor permite scripts de mesma origem, mas não manipuladores inline. Testes de API não exercitam esse bloqueio.',
    'Vincular os eventos das telas por JavaScript compatível com a CSP e verificar os fluxos pela interface. Não desativar a proteção como substituto da correção.',
    'Navegar e executar inclusões, alterações, consultas e relatórios nos cinco módulos sem violações CSP, com os respectivos perfis.',
    [evidence('app.py', 'Content-Security-Policy'), evidence('static/finance-ui.js'), evidence('static/social-ui.js'), evidence('static/bi-ui.js'), 'artifacts/auditoria-20260924/browser.json'], clauses=['4.45','4.72.5','4.80.6'])
add('AUD-003', 'Crítica', 'Permissão de consulta permite gravação financeira', keys('finance',1,70,71,181,182,190,191,225,226)+keys('general',9,16),
    'Reprodução com conta temporária finance:[read], sem write: POST /api/finance/rules retornou 201 e persistiu regra. O decorador require_auth verifica somente finance/read, inclusive em várias rotas POST. Não equivale à dupla custódia dos cadastros administrativos antigos.',
    'Aplicar autorização por ação, entidade e operação financeira; garantir aprovação independente quando configurada e registrar autoria real.',
    'Leitores recebem 403 em toda mutação; nenhuma linha é alterada; autores não aprovam as próprias operações.',
    [evidence('finance_api.py','require_auth'), evidence('finance_api.py','handle_rules'), 'artifacts/auditoria-20260924/probes.json'], clauses=['4.42','4.43','4.50'])
add('AUD-004', 'Crítica', 'Consultas de pessoal sem permissão de módulo ou lotação', keys('people',2,10,33,109,110,111,112,113,114),
    'Conta autenticada sem qualquer permissão recebeu 200 em employees, positions e sst/monitors. As consultas de people_api.py não exigem people/read, e get_work_locations ignora o parâmetro de entidade. A autenticação global não substitui autorização por lotação.',
    'Restringir todas as consultas de RH, SST e cadastro por módulo, entidade, lotação e titular; verificar também escrita e exportações.',
    'Matriz de acessos negativos entre dois usuários, duas lotações e duas entidades, inclusive por ID direto, sem retorno de dados não autorizados.',
    [evidence('people_api.py','list_employees'), evidence('people_api.py','list_monitors'), evidence('people_core.py','get_work_locations'), 'artifacts/auditoria-20260924/probes.json'], clauses=['4.23','4.28','4.43'])
add('AUD-005', 'Crítica', 'Cadastro público por CPF é apresentado como autenticação SIAFIC', keys('finance',70,71,181,182,190,191,225,226),
    'POST público /api/public/finance/siafic/auth aceitou CPF 000, criou cadastro ativo e marcou termo aceito sem senha, autorizador ou anexo. Esse endpoint tampouco estabelece autenticação CPF na sessão principal.',
    'Implementar autenticação efetiva por CPF, validação de identidade, autorização de acesso e termo real; não aceitar responsabilidade em nome do usuário.',
    'CPF inválido, conta não autorizada e ausência de prova de identidade são rejeitados. A sessão autenticada é vinculada ao CPF e ao aceite comprovado.',
    [evidence('finance_core.py','authenticate_siafic_cpf'), evidence('finance_api.py','handle_siafic_auth'), 'artifacts/auditoria-20260924/probes.json'], status='Não implementado')
add('AUD-006', 'Crítica', 'Contracheque inexistente é declarado autêntico', keys('people',77),
    'A validação pública retornou autentico:true para token INVALIDO, matrícula 999999 e competência 1900-01. verify_payslip_public não verifica HMAC nem a existência do documento.',
    'Conferir assinatura/token, vínculo, competência e valores contra o documento persistido; usar chave protegida e URL institucional configurada.',
    'Tokens inventados, adulterados ou de documentos inexistentes são rejeitados; documento íntegro é validado sem expor dados além dos necessários.',
    [evidence('people_api.py','verify_payslip_public'), evidence('people_core.py','generate_payslip_qr_token'), 'artifacts/auditoria-20260924/probes.json'], status='Não implementado')
add('AUD-007', 'Crítica', 'Demonstrativos, limites e apurações usam valores fixos', keys('finance',19,20,21,22,23,24,25,28,45,57,151,range(161,180)),
    'Balanço do exercício 2099, em base sem lançamentos financeiros, retornou receita realizada de 837.000.000. generate_anexo*, PASEP, duodécimo, RREO e RGF contêm valores literais; parâmetros de período e filtros não produzem apuração correspondente.',
    'Apurar cada demonstrativo a partir da escrituração real, com todos os quadros, filtros, comparativos e critérios previstos no respectivo item.',
    'Base vazia não gera fatos; lançamentos controlados alteram os resultados exatos, conciliados com razão e balancete por entidade e período.',
    [evidence('finance_core.py','generate_anexo12_balanco_orcamentario'), evidence('finance_core.py','calculate_pasep'), evidence('finance_core.py','generate_rreo_report'), 'artifacts/auditoria-20260924/probes.json'])
add('AUD-008', 'Alta', 'SIOPS e SIOPE não exportam a execução real', keys('finance',14,15,16,17,18,30,31,32),
    'As funções generate_siops_export e generate_siope_export devolvem pastas e montantes fixos. A existência de chaves no JSON não demonstra arquivos de terceiros importáveis nem atualização automática dos relacionamentos.',
    'Completar mapeamentos versionados, apuração, arquivos aceitos pelos destinatários e relatórios de conferência.',
    'Importar arquivos gerados em ambiente oficial aplicável e conciliar cada total com movimentações de teste, registrando versões e críticas.',
    [evidence('finance_core.py','generate_siops_export'), evidence('finance_core.py','generate_siope_export')])
add('AUD-009', 'Crítica', 'MSC aceita texto inválido como XBRL validado', keys('finance',8,9,10,11,12,13,53,80),
    'Texto sem XML, contendo apenas matrizSaldosContabeis, foi aceito com status VALIDATED. O importador testa substrings; não carrega fatos importados na consulta. O gerador usa estrutura XML própria e informações complementares fixas.',
    'Validar conteúdo e estrutura oficiais, persistir os fatos, consolidar entidades e disponibilizar todas as críticas e filtros previstos.',
    'XML malformado e arquivo fora do leiaute são rejeitados; arquivo válido consolida saldos e informações complementares com rastreabilidade.',
    [evidence('finance_core.py','import_msc_file'), evidence('finance_core.py','generate_msc_file'), evidence('finance_core.py','query_msc_movements'), 'artifacts/auditoria-20260924/probes.json'])
add('AUD-010', 'Crítica', 'Transmissão EFD-Reinf simulada', keys('finance',187,188,189),
    'validate_and_transmit_reinf_event monta xml_mock e recibo local sem transporte ao WebService. Não confundir com os conectores eSocial/PNCP existentes em outros arquivos.',
    'Completar geração por leiaute, validação, assinatura, envio, retorno e estados de erro/retificação da EFD-Reinf.',
    'Guardar protocolo retornado pelo destinatário em homologação; indisponibilidade e rejeição não podem resultar em recibo de sucesso local.',
    [evidence('finance_core.py','validate_and_transmit_reinf_event')], status='Não implementado')
add('AUD-011', 'Crítica', 'OBE, PIX e retornos bancários simulados', keys('finance',87,192,193,194,229),
    'O lote calcula R$ 15.000 por ID de empenho, fabrica uma string CNAB e marca Remessa_Enviada. O retorno detecta a palavra REJEICAO e atribui rejeição de 10%, sem leitura de ocorrências e transações reais.',
    'Usar obrigações autorizadas e valores efetivos, leiautes bancários, transporte/arquivos, conciliação dos retornos e estornos contábeis correspondentes.',
    'Lotes e PIX homologados por banco, com valores idênticos aos empenhos e rejeições por transação sem liquidação fictícia.',
    [evidence('finance_core.py','generate_obe_batch'), evidence('finance_core.py','process_bank_return_file')], status='Não implementado')
add('AUD-012', 'Crítica', 'Importação OFX ignora arquivo e conciliação força sucesso', keys('finance',197,219,220,221,222),
    'import_ofx_statement não utiliza o conteúdo para gerar os movimentos: grava três operações fixas e saldos fixos. auto_reconcile_ofx marca todas as linhas como conciliadas e zera a diferença sem pareamento.',
    'Ler o OFX real, preservar FITID/data/valor, comparar com movimentos internos, respeitar bloqueios e manter divergências visíveis.',
    'Arquivos diferentes geram extratos diferentes; arquivo inválido é rejeitado; divergências não desaparecem e duplicidade de FITID é controlada.',
    [evidence('finance_core.py','import_ofx_statement'), evidence('finance_core.py','auto_reconcile_ofx')], status='Não implementado')
add('AUD-013', 'Alta', 'MANAD e SIGFIS não contêm prestação de contas completa', keys('finance',183,184),
    'MANAD contém apenas cabeçalho/rodapé; SIGFIS retorna um elemento XML sem os fatos da prestação e sem declaração do prefixo utilizado.',
    'Gerar leiautes completos, versionados e conciliados com os fatos contábeis e de pessoal, com validação apropriada.',
    'Arquivos são aceitos pelos validadores aplicáveis e contêm todos os registros necessários, inclusive casos de cancelamento e retificação.',
    [evidence('finance_core.py','export_manad_file'), evidence('finance_core.py','export_sigfis_tcerj')], status='Não implementado')
add('AUD-014', 'Alta', 'Fluxos novos não demonstram integração com a escrituração ERP', keys('finance',36,37,49,50,51,52,82,143,144,145,146,185,200,207,208,209,210),
    'A execução ERP grava erp_ledger/erp_objects; relatórios e MSC novos consultam finance_journal_entries e cadastros próprios. Não foi evidenciado vínculo automático completo entre essas duas bases funcionais.',
    'Integrar os registros e os relatórios ao mesmo conjunto de fatos, preservando identidade, entidade, exercício e atomicidade.',
    'Um fluxo de compra, entrada, liquidação e pagamento aparece exatamente uma vez em razão, MSC, BI e transparência, incluindo estorno.',
    [evidence('erp_operations.py'), evidence('inventory_core.py'), evidence('finance_core.py','generate_msc_file')])
add('AUD-015', 'Alta', 'Resumo contratual agrega empenhos de outros contratos', keys('procurement',21,22,50),
    'get_contract_financial_summary lê process_id, mas seleciona empenhos apenas pelo fornecedor, sem filtrar processo, contrato, entidade ou exercício. Contratos do mesmo fornecedor podem receber totais alheios.',
    'Apurar saldo por vínculo contratual e contexto, considerando empenhos complementares, cancelamentos e instrumentos previstos.',
    'Dois contratos do mesmo fornecedor em entidades/exercícios distintos mantêm totais independentes e conciliados.',
    [evidence('procurement_core.py','get_contract_financial_summary')])
add('AUD-016', 'Alta', 'Regularidade do fornecedor não comprova consulta tributária municipal', keys('procurement',43,45),
    'check_supplier_compliance consulta certidões locais e considera compliant quando não há vencidas, mesmo listando certidões ausentes. Não realiza consulta à situação tributária municipal.',
    'Completar a consulta tributária e distinguir regular, irregular e não comprovado; tratar a ausência de documentos conforme os controles exigidos.',
    'Fornecedor sem certidões ou sem resposta da fonte não é apresentado como regularidade comprovada; relatório aplica os filtros do item 45.',
    [evidence('procurement_core.py','check_supplier_compliance')])
add('AUD-017', 'Crítica', 'Pregão: nove plataformas cadastradas, integração efetiva ausente', keys('auction',1),
    'Mesmo simulate=False e endpoint inválido, transmit_exchange_package retorna TRANSMITIDO com recibo calculado localmente. import_exchange_results pode fabricar vencedores. Não há transporte nem recebimento comprovado de lances por item/lote, atas e resultado das nove plataformas.',
    'Implementar e homologar envio/recebimento de cada plataforma exigida, com contratos reais, autenticação, idempotência e validação de retornos.',
    'Nove roteiros ponta a ponta, com recibos externos e conferência de propostas, lances, atas e resultado; nenhuma resposta local pode se passar por homologação externa.',
    [evidence('auction_core.py','transmit_exchange_package'), evidence('auction_core.py','import_exchange_results'), evidence('auction_api.py','webhook'), 'artifacts/auditoria-20260924/probes.json'], status='Não implementado')
add('AUD-018', 'Crítica', 'Segredo de pregão persistido em texto claro', keys('auction',1),
    'configure_platform grava o token diretamente na coluna client_token_enc. Reproduzido com marcador fictício: conteúdo persistido idêntico à entrada.',
    'Usar cofre criptográfico, acesso restrito, mascaramento e rotação também neste caminho alternativo de integração.',
    'Banco e logs não contêm token em claro; a rotina de transporte consegue utilizá-lo apenas sob autorização.',
    [evidence('auction_core.py','configure_platform'), 'artifacts/auditoria-20260924/probes.json'], clauses=['4.27','4.28','4.32'])
add('AUD-019', 'Crítica', 'Datacenters e recuperação geográfica são registros simulados', keys('cloud',1,4),
    'init_cloud_db insere DC-RJ/DC-SP fictícios; simulate_dr_failover apenas inverte flags SQL e retorna RTO/RPO fixos. Não comprova residência selecionável, replicação ou snapshot entre regiões.',
    'Provisionar e comprovar provedor, regiões, residência dos dados, serviço relacional, cópias entre regiões e recuperação real.',
    'Inventário do provedor e exercício de restauração/failover com dados conhecidos, tempos medidos e evidência de independência regional.',
    [evidence('cloud_core.py','init_cloud_db'), evidence('cloud_core.py','simulate_dr_failover')], status='Dependência externa', clauses=['4.53.5','4.66.2','4.79.2'])
add('AUD-020', 'Crítica', 'As nove certificações do provedor não foram comprovadas', keys('cloud',2),
    'O requisito pede ISO 27001, 27017, 27018, 27701, 22301, 9001 e SOC 1, 2, 3. A cobertura anterior citava apenas SLA 99,98%, que não comprova nenhuma dessas certificações. Não foi apresentado provedor contratado com esse conjunto documental.',
    'Apresentar documentos ou referências públicas em nome do provedor, com validade e escopo correspondentes ao serviço ofertado.',
    'Conferência documental das nove certificações/acreditações e do vínculo com a infraestrutura efetivamente utilizada.',
    [evidence('tools/update_final_compliance.py'), 'ANEXO III.pdf: página física 2, impressa 85'], status='Dependência externa')
add('AUD-021', 'Alta', 'HTTPS e acesso externo não comprovados na instalação local', keys('cloud',3)+keys('general',6)+keys('control',2)+keys('bi',3),
    'A instalação examinada está em http://127.0.0.1:8080 e informa ambiente Local. SECURE_COOKIE/HSTS condicionais não provisionam TLS nem acesso por computador fora da rede.',
    'Implantar endpoint HTTPS institucional e testar o acesso externo aos produtos, com certificado válido, redirecionamento e configuração segura de cookies.',
    'Acesso real de rede externa e validação TLS de todos os produtos; nenhuma alegação de TLS 1.3 somente por existência de cabeçalhos.',
    [evidence('app.py','SECURE_COOKIE'), 'artifacts/auditoria-20260924/browser.json'], status='Dependência externa', clauses=['4.29','4.38'])
add('AUD-022', 'Alta', 'Dashboard de usuários do provedor não demonstrado', keys('cloud',5),
    'cloud.5 exige criação, inativação e reset de senha dos usuários do provedor. O status de CPU/RAM/NVMe descrito na cobertura anterior não atende esse objeto. Administração de usuários da aplicação é outro escopo.',
    'Demonstrar o painel de identidades do provedor e as três operações exigidas, com perfis e trilha de auditoria.',
    'Criar conta de teste no painel do provedor, inativá-la, comprovar o bloqueio e realizar o reset de senha.',
    [evidence('cloud_api.py'), 'ANEXO III.pdf: página física 2, impressa 85'], status='Dependência externa')
add('AUD-023', 'Alta', 'Escalabilidade e redimensionamento são flags fixas', keys('cloud',6,7),
    'get_cloud_infrastructure_status retorna auto_scaling_enabled=True, 4/16 nós e resizing=True sem comunicação com infraestrutura ou medição de carga.',
    'Configurar escalabilidade e redimensionamento do ambiente ofertado e demonstrar o comportamento sob carga e o prazo de resizing.',
    'Medição antes/depois de CPU, memória, disco, nós e latência, com resizing médio de 5 minutos conforme o item.',
    [evidence('cloud_core.py','get_cloud_infrastructure_status')], status='Dependência externa')
add('AUD-024', 'Crítica', 'Trinta backups de nuvem e integridade fictícios', keys('cloud',8),
    'São inseridas 30 linhas com tamanhos e hashes de dummy_content. verify_backup_integrity só atualiza o status para VERIFICADO_OK e não lê um arquivo. Há backup local real em backup.py, mas isso não comprova backup diário do provedor com retenção de 30 dias.',
    'Implementar política operacional comprovada no provedor, entrega ao contratante e testes periódicos de restauração dos arquivos efetivos.',
    'Inventário de arquivos reais dos 30 dias, hashes verificados, download e restauração de amostras sem depender de tabelas simuladas.',
    [evidence('cloud_core.py','verify_backup_integrity'), evidence('cloud_core.py','init_cloud_db'), evidence('backup.py'), 'artifacts/auditoria-20260924/probes.json'], status='Dependência externa')
add('AUD-025', 'Crítica', 'SOC, NOC, endpoint protection e WAF não comprovados', keys('cloud',9,10,11,12),
    'Eventos são semeados e respostas de monitoramento/EDR são literais. simulate_waf_block insere um registro e retorna status 403 em JSON; não demonstra bloqueio de tráfego na borda, DDoS, bots ou integração SOC. cloud.10 exige NOC, não apenas armazenamento de logs.',
    'Comprovar serviços e controles 24x7x365 do provedor, agentes, inteligência, resposta automatizada, monitoramento de rede e firewall profissional.',
    'Documentação e teste autorizado de detecção/bloqueio real, escalonamento de incidente, correlação e resposta em cada componente requerido.',
    [evidence('cloud_api.py','get_soc_dashboard'), evidence('cloud_core.py','simulate_waf_block')], status='Dependência externa')
add('AUD-026', 'Alta', 'Replicação de pessoal registra conclusão sem copiar dados', keys('people',1),
    'replicate_entity_data apenas insere people_entities_replication com COMPLETED. Não copia cargos, servidores, lotações ou verbas para uma base segregada de simulação.',
    'Executar replicação efetiva e segregada dos cadastros e permitir cálculos/relatórios na cópia preservando a origem.',
    'Comparar contagens e vínculos na origem e destino, modificar e calcular a cópia e comprovar que a base principal não mudou.',
    [evidence('people_core.py','replicate_entity_data')], status='Não implementado')
add('AUD-027', 'Crítica', 'Conferência eSocial compara valores com cópia de si mesmos', keys('people',99,108),
    'generate_esocial_totalizers_reconciliation calcula alíquotas fixas e copia o resultado para esoc_*, marcando divergências=0 e CONCILIADO_100_PORCENTO. Não lê totalizadores de retorno. O transporte real existente em integration_esocial_* não sana este comparativo.',
    'Relacionar apurações por trabalhador/competência aos eventos e totalizadores efetivamente recebidos, explicitando ausências e divergências.',
    'Um retorno externo divergente gera crítica; ausência de retorno impede declaração de conciliação.',
    [evidence('people_core.py','generate_esocial_totalizers_reconciliation'), evidence('integration_esocial.py')])
add('AUD-028', 'Alta', 'Atualizações oficiais de pessoal não estão demonstradas', keys('people',64,65,66,67,68,82,115),
    'get_official_inss_table e get_cbo_catalog consultam tabelas locais. lookup_cep_correios contém fallback simulado. Não foi demonstrada atualização automática de RGPS/IR/salário mínimo nem integração efetiva com a base indicada no PDF.',
    'Completar aquisição, validação, vigência e atualização dos dados oficiais e exibir origem/data; não retornar endereço inventado.',
    'Troca de versão oficial é refletida no cadastro e no cálculo; falha de fonte é sinalizada, com preservação da versão anterior validada.',
    [evidence('people_core.py','get_official_inss_table'), evidence('people_core.py','get_cbo_catalog'), evidence('people_core.py','lookup_cep_correios')])
add('AUD-029', 'Alta', 'Portal do servidor possui autorização e consulta pendentes', keys('people',71,72,76,78,79,80,81),
    'Primeiro acesso provisiona senha para CPF conhecido sem verificação adicional; rotas usam employee_id fornecido pelo cliente sem vínculo de titularidade. A listagem de atualizações pendentes faz JOIN com erp_people_employees, tabela não criada pelos schemas consultados (cadastro usa people_employees).',
    'Estabelecer acesso do titular, recuperação verificada, validação de comprovantes e revisão RH sobre a tabela correta, com atualização auditada.',
    'Servidor A não consulta nem propõe mudanças para B; fila RH carrega e permite validar/rejeitar com anexos; recuperação envia link real ao endereço cadastrado.',
    [evidence('people_core.py','portal_authenticate'), evidence('people_api.py','submit_portal_update'), evidence('people_api.py','list_pending_updates')])
add('AUD-030', 'Crítica', 'RMA CRAS/CREAS/POP contém quantitativos artificiais', keys('social',range(92,103)),
    'RMA CREAS e POP inserem quantitativos fixos quando não existe apuração; CRAS utiliza constantes e proporções não derivadas de todos os atendimentos do período. O XML usa código IBGE divergente daquele empregado nas integrações municipais do projeto. Não há evidência de aceite oficial do leiaute gerado.',
    'Calcular cada campo dos formulários a partir dos fatos da unidade/mês, prover ajuda de origem, ajustes auditados e XML validado para o destinatário.',
    'Unidade sem atendimentos não recebe valores fictícios; um atendimento controlado altera somente os campos correspondentes e fecha com conciliação analítica.',
    [evidence('social_core.py','get_or_calculate_rma_cras'), evidence('social_core.py','get_or_calculate_rma_creas'), evidence('social_core.py','get_or_calculate_rma_pop'), evidence('social_core.py','export_rma_cras_xml')])
add('AUD-031', 'Crítica', 'Assinatura social P7S e certificado são simulados', keys('social',range(280,291)),
    'sign_document_icp concatena prefixo Base64 e hash, usa serial fixo ICP-BR-RO-2026-X509 e grava validade padrão. verify_digital_signature consulta a flag; não verifica chave, certificado, conteúdo ou prazo. Hash sozinho não é assinatura digital.',
    'Integrar a assinatura criptográfica dos documentos sociais, confirmação do certificado válido, formatos exigidos, verificação independente, alertas e consultas.',
    'Documento adulterado e certificado vencido são rejeitados; P7S/PDF é verificável por ferramenta independente e preserva o conteúdo assinado.',
    [evidence('social_core.py','sign_document_icp'), evidence('social_core.py','verify_digital_signature')], status='Não implementado')
add('AUD-032', 'Alta', 'Georreferenciamento social não demonstra todos os modos exigidos', keys('social',range(45,58)),
    'As rotinas localizadas produzem pontos/diagnóstico; não foi comprovada a execução integral de mapa interativo, satélite, vistas 360°, delimitações e geocodificação automática do endereço. A nota anterior reutilizava a mesma referência para os 13 itens.',
    'Demonstrar cada modo e filtro em navegador; completar as funções ausentes, com fonte geográfica e configuração apropriadas.',
    'Cadastrar endereço, obter coordenada correspondente e navegar em todos os modos exigidos, distinguindo pessoa/família e restrições de acesso.',
    [evidence('social_core.py','get_territorial_heatmap'), evidence('static/social-ui.js')], status='Não comprovado')
add('AUD-033', 'Alta', 'SMS de agendamento sem fluxo de envio comprovado', keys('social',116,117,118),
    'A cobertura anterior destes itens citava RMA, sem relação com SMS. Não foram localizados envio SMS, configuração de provedor, fila ou status de entrega/erro no fluxo social examinado.',
    'Implementar configuração, mensagens parametrizadas com dados do agendamento, envio efetivo e gerenciamento de falhas.',
    'Mensagem de agendamento recebida em destino de homologação, com status real e erro/reenvio rastreável.',
    [evidence('tools/update_social_compliance.py'), evidence('social_api.py'), evidence('social_core.py')], status='Não implementado', clauses=['4.80.6'])
add('AUD-034', 'Alta', 'Importadores sociais cobrem somente parte das bases exigidas', keys('social',range(401,420)),
    'Foram localizados process_cadunico_import e process_sicon_import. Não há comprovação do conjunto de importações periódicas da folha do benefício, Sibec, BPC e CECAD com progresso, filtros e motivo por registro. A nota anterior atribuía o mesmo atendimento a todos os itens.',
    'Completar cada importador e os respectivos leiautes, periodicidade, progresso, críticas e vínculos; validar arquivos representativos fornecidos pelo município.',
    'Para cada base, arquivo válido/importação repetida/registro inválido têm resultados rastreáveis por pessoa e família, sem duplicação.',
    [evidence('social_core.py','process_cadunico_import'), evidence('social_core.py','process_sicon_import'), evidence('social_api.py')], status='Não comprovado')
add('AUD-035', 'Alta', 'Sigilo por especialidade e unidade não comprovado no novo módulo social', keys('social',178,180,254,279,328,329),
    'A proteção social_confidential existe no ERP genérico, mas as novas rotas /api/social usam permissões amplas de módulo. Não foi demonstrada política por especialidade, unidade e profissional em toda consulta, histórico, alteração e exportação.',
    'Unificar a política de sigilo nos caminhos novos e antigos, com autorização do objeto e campos sensíveis.',
    'Profissional de outra especialidade/unidade não acessa o registro por ID, busca, relatório ou histórico; acessos autorizados ficam auditados.',
    [evidence('erp_core.py','confidential_sql'), evidence('social_api.py'), evidence('social_core.py','get_family_details')], status='Não comprovado', clauses=['4.23','4.28','4.43'])
add('AUD-036', 'Alta', 'E-mail de controladoria apenas registrado localmente', keys('control',16,23,27),
    'send_obligation_email grava acompanhamento e notificação interna; não chama transporte SMTP/API. Registrar destinatário e mensagem não comprova comunicação externa ou avisos de vencimento.',
    'Completar envio real, configuração, fila, agenda de vencimentos, erro e evidência de entrega; preservar o histórico.',
    'Destinatário recebe a mensagem, tentativas e falhas ficam registradas e avisos respeitam os prazos da obrigação.',
    [evidence('control_core.py','send_obligation_email')])
add('AUD-037', 'Crítica', 'Ranking SICONFI reprocessado por resultado predefinido', keys('control',30,31,32,33,34,35,36,37,38,39,40,45,46,47),
    'reprocess_siconfi_period marca regras como Conforme e força uma exceção para STN-D2-02, com divergência fixa. Não executa as verificações sobre a informação contábil/fiscal do período. O conector de extrato de obrigações existente tem outra finalidade.',
    'Executar regras oficiais versionadas sobre os dados do período, por dimensão e poder, com memória de cálculo e origem.',
    'Alterar dados de entrada produz as divergências esperadas em cada regra, sem resultados definidos pelo código do requisito.',
    [evidence('control_core.py','reprocess_siconfi_period'), evidence('integration_siconfi.py')])
add('AUD-038', 'Alta', 'Integrações CAUC e convênios dependem de comprovação', keys('control',54,56,70,72),
    'Os dashboards consultam control_cauc_requirements/control_agreements locais. Carga seed e painel não demonstram importação atualizada dos serviços de dados abertos pedidos nesses itens.',
    'Completar ou evidenciar os conectores, atualização, histórico da origem e falhas de sincronização.',
    'Mudança controlada na fonte é refletida no painel com data de consulta e histórico, sem substituir falha por regularidade fictícia.',
    [evidence('control_core.py','get_cauc_dashboard'), evidence('control_core.py','get_agreements_dashboard'), evidence('control_seed.py')], status='Não comprovado')
add('AUD-039', 'Crítica', 'BI apresenta indicadores fixos ou sem vínculo com a execução', keys('bi',1,range(11,53)),
    'Painel LRF usa percentuais/valores de fallback e indicadores literais de Legislativo, dívida e operações. As tabelas bi_* não demonstram atualização integrada de todos os fatos. Em exercício sem dados, há fallback de outro exercício. Não confundir com erp_insights, que possui consultas reais limitadas.',
    'Ligar cada indicador à fonte operacional, competência, entidade e filtros; sinalizar ausência de dados e completar comparativos e detalhamentos exigidos.',
    'Inserir, alterar e estornar fatos controlados de finanças, pessoas, compras e patrimônio muda cada indicador correspondente; exercício vazio não reutiliza outro sem aviso.',
    [evidence('bi_core.py','get_executive_lrf_dashboard'), evidence('bi_seed.py'), evidence('erp_insights.py'), 'artifacts/auditoria-20260924/probes.json'])
add('AUD-040', 'Crítica', 'Transparência publica dados demonstrativos e valores presumidos', keys('transparency',range(45,60),80,132,133,134,146,147),
    'seed_transparency é chamado incondicionalmente ao iniciar, inclusive demo=False, e insere dívidas/emendas fictícias. query_personnel acrescenta servidores de exemplo; patrimônio/estoque completam campos com valores, fornecedor, saldos e URLs inventados. As configurações padrão são sobrescritas em toda inicialização.',
    'Separar demonstração de dados publicáveis, remover fallback fictício de consultas reais, preservar configuração institucional e publicar somente informação efetiva e conferida.',
    'Instalação sem demonstração não publica fatos inventados; reiniciar preserva parâmetros; saldos e anexos públicos correspondem às bases e arquivos reais.',
    [evidence('transparency_api.py','install_transparency'), evidence('transparency_seed.py','seed_transparency'), evidence('transparency_core.py','query_personnel'), evidence('transparency_core.py','query_assets_detailed'), evidence('transparency_core.py','query_inventory_with_supplier')])
add('AUD-041', 'Alta', 'Demonstrativos patrimoniais TCE-RJ não comprovados integralmente', keys('assets',27),
    'report(tce) usa a mesma listagem patrimonial de depreciação/responsabilidade, com bens ativos e posição atual. Não há evidência de todos os demonstrativos, modelos e conciliação histórica necessários ao item. Os testes comprovam emissão da listagem, não homologação do modelo pelo TCE.',
    'Identificar e gerar cada demonstrativo aplicável à exigência do PDF, com período, saldos, responsáveis e conciliação validados.',
    'Conferência dos demonstrativos por responsável contábil e confronto com saldos conhecidos, movimentações e modelo exigido.',
    [evidence('asset_api.py','report'), evidence('tests/test_assets.py')], status='Não comprovado')
add('AUD-042', 'Alta', 'Fotos de obras registram nome sem conteúdo ou arquivo vinculado', keys('works',1,7,8,14,40,42),
    'upload_diary_photo recebe filename/caption e insere metadados, mas não recebe imagem nem referencia anexo protegido existente. Aprovar essa linha não comprova foto disponível para o diário/portal.',
    'Vincular cada foto a conteúdo armazenado, validar tipo/tamanho/autorização e publicar apenas as fotos aprovadas.',
    'Upload, download, prévia do diário e portal reproduzem a mesma imagem; nome sem arquivo é rejeitado e foto não aprovada fica protegida.',
    [evidence('works_api.py','upload_diary_photo')])
add('AUD-043', 'Média', 'Google Maps de obras abre fora do sistema', keys('works',27),
    'worksProjectDetail renderiza coordenadas e link target=_blank. O PDF pede visualização numa tela Google Maps dentro do sistema.',
    'Disponibilizar a visualização interna exigida com configuração e restrições apropriadas, mantendo os vínculos das obras.',
    'A obra aparece em mapa interativo dentro da tela da aplicação, nas coordenadas informadas.',
    [evidence('static/works-ui.js','works-map-placeholder')])
add('AUD-044', 'Alta', 'Mil almoxarifados: cadastro testado, simultaneidade não comprovada', keys('inventory',1),
    'test_more_than_one_thousand_interconnected_warehouses passou e cria 1.001 almoxarifados sequencialmente com uma transferência. Isso comprova capacidade cadastral, mas não operação simultânea acima de 1.000 unidades com disputa de saldo.',
    'Executar prova de carga concorrente representativa com transferências e rastreabilidade, mantendo consistência dos saldos.',
    'Mais de 1.000 unidades operam no cenário simultâneo definido, com medição de latência, falhas, integridade e saldos em trânsito.',
    [evidence('tests/test_inventory_controls.py','test_more_than_one_thousand_interconnected_warehouses'), evidence('tools/performance_erp_check.py')], status='Não comprovado')
add('AUD-045', 'Alta', 'Relatórios históricos da frota usam localização atual', keys('fleet',19,20,22,24,25),
    'fleet_api.report associa eventos antigos à localização e aos atributos patrimoniais atuais retornados por _vehicles. Uma transferência posterior pode alterar os agrupamentos de um período já encerrado. Falta prova histórica dessa situação.',
    'Definir e preservar localização e atributos na data do fato para os relatórios históricos; conciliar todos os custos por período.',
    'Transferir veículo após o período não altera o relatório daquele período; custos por km/h incluem exatamente seus eventos e o agrupamento temporal correto.',
    [evidence('fleet_api.py','_vehicles'), evidence('fleet_api.py','report')])
add('AUD-046', 'Alta', 'Novas telas enviam POST sem token CSRF', [],
    'Os helpers/fetch de Pessoas, Finanças, Social e BI enviam JSON sem X-CSRF-Token em operações protegidas. A autenticação global exige o token; portanto, além do bloqueio CSP, esses fluxos têm impedimento adicional para gravar.',
    'Usar o cliente autenticado comum e tratar respostas de erro antes de informar sucesso, conservando a proteção CSRF.',
    'Após resolver os eventos, cada operação pela tela envia token válido, grava quando autorizada e exibe falhas reais sem falso sucesso.',
    [evidence('static/people-ui.js','async function apiCall'), evidence('static/finance-ui.js', "fetch('/api/finance/journal/post'"), evidence('static/social-ui.js', "fetch('/api/social/rma/cras/close'"), evidence('static/bi-ui.js', "fetch('/api/bi/share'"), evidence('auth.py','X-CSRF-Token')], clauses=['4.45','4.72.5'])
add('AUD-047', 'Alta', 'Reajuste de obras não preserva integralmente a planilha anterior', keys('works',36,37),
    'linear_adjustment altera os dados dos mesmos itens de erp_objects e grava uma linha de versão com total; essa rotina não guarda snapshot completo dos itens anteriores nem desativa as versões anteriores. Falta demonstrar reconstrução fiel das planilhas e medições subsequentes.',
    'Preservar as versões completas da planilha e vincular medições à versão correta, sem reprecificar retroativamente fatos encerrados.',
    'Após reajuste/supressão, recuperar cada versão anterior com quantidades e preços exatos, mantendo os valores de medições já aprovadas.',
    [evidence('works_operations.py','linear_adjustment'), evidence('works_schema.sql')])
add('AUD-048', 'Média', 'Políticas de senha e bloqueio não têm toda a parametrização pedida', keys('general',2,7),
    'check_password aceita somente nível Forte. max_attempts/lock_minutes são globais em settings, embora o PDF mencione bloqueio com período definido por usuário. Classificação visual não comprova os três níveis configuráveis exigidos.',
    'Resolver a aderência da política de níveis e parametrização por usuário com a contratante, preservando segurança e formalizando a regra aceita.',
    'Demonstrar as configurações previstas ou aceite formal da divergência; comprovar bloqueio, troca obrigatória e invalidação de sessões por usuário.',
    [evidence('auth.py','check_password'), evidence('auth.py','login'), evidence('db.py','DEFAULTS')], clauses=['4.36','4.36.1','4.39'])

now = datetime.now(timezone.utc).isoformat(timespec='seconds')
assert len(catalog['items']) == len(old['items']) == 1314
assert {x['key'] for x in old['items']} == {x['key'] for x in catalog['items']}
assert len({x['key'] for x in catalog['items']}) == 1314
for a,b in zip(old['items'],catalog['items']):
    assert (a['key'],a['text'],a['page']) == (b['key'],b['text'],b['page'])
for f in findings:
    assert set(f['requirements']) <= {x['key'] for x in catalog['items']}, f['id']

def finding_text(f):
    return (f"{f['id']} | Prioridade {f['severity']} | {f['title']}\n"
        f"Constatação: {f['observation']}\nCorreção/implementação necessária (NÃO EXECUTADA): {f['action']}\n"
        f"Como comprovar o atendimento: {f['acceptance']}\nEvidências: {'; '.join(f['evidence'])}.")

by_key = defaultdict(list)
for f in findings:
    for k in f['requirements']:
        by_key[k].append(f)
confirmed = {
    'general.3': ['auth.py:require', 'admin.py', 'tests/test_system.py::test_individual_override'],
    'general.8': ['auth.py:allowed_time', 'tests/test_system.py::test_schedule_blocks_login'],
    'general.10': ['auth.py:login', 'tests/test_system.py::test_lockout_and_login_audit'],
    'general.12': ['admin.py', 'tests/test_system.py::test_personal_shortcuts_isolated'],
    'general.13': ['admin.py', 'db.py:init_db', 'tests/test_system.py::test_maintenance_runs_only_registered_scripts'],
}
module_files = {
    'general':'auth.py, admin.py, app.py, reports.py, tests/test_system.py',
    'cloud':'cloud_core.py, cloud_api.py, backup.py',
    'finance':'finance_core.py, finance_api.py, finance_schema.sql, erp_operations.py, tests/test_finance.py',
    'control':'control_core.py, control_api.py, integration_siconfi.py, tests/test_control.py',
    'people':'people_core.py, people_api.py, people_schema.sql, erp_payroll.py, integration_esocial.py, tests/test_people.py',
    'procurement':'procurement_core.py, procurement_operations.py, procurement_api.py, procurement_catalog.py, tests/test_procurement.py',
    'auction':'auction_core.py, auction_api.py, tests/test_final_compliance.py',
    'inventory':'inventory_core.py, inventory_operations.py, inventory_catalog.py, inventory_reports.py, tests/test_inventory.py, tests/test_inventory_controls.py',
    'assets':'asset_core.py, asset_accounting_operations.py, asset_management_operations.py, asset_catalog.py, tests/test_assets.py',
    'bi':'bi_core.py, bi_api.py, erp_insights.py, tests/test_bi.py',
    'transparency':'transparency_core.py, transparency_api.py, transparency_seed.py, static/transparency-ui.js, tests/test_transparency.py',
    'fleet':'fleet_core.py, fleet_operations.py, fleet_api.py, fleet_catalog.py, tests/test_fleet.py',
    'social':'social_core.py, social_api.py, social_schema.sql, erp_social_operations.py, tests/test_social.py',
    'works':'works_core.py, works_api.py, works_operations.py, works_catalog.py, tests/test_works.py',
}
transversal = {'finance':['AUD-002','AUD-003','AUD-046'], 'people':['AUD-002','AUD-004','AUD-046'], 'control':['AUD-002'], 'social':['AUD-002','AUD-035','AUD-046'], 'bi':['AUD-002','AUD-046']}
audited = []
for original in old['items']:
    x = dict(original)
    related = by_key[x['key']]
    prior = {'status': original['status'], 'coverage': original['coverage'], 'before': original.get('before','')}
    x['before'] = 'Antes desta auditoria: ' + original['status'] + '. Alegação anterior (não equivale a comprovação): ' + original['coverage']
    x['audit'] = {'date':now, 'source':old['source'], 'prior':prior, 'findings':[f['id'] for f in related], 'transversal_findings':transversal.get(x['module'],[]), 'full_acceptance_tested':False}
    if related:
        precedence = ['Não implementado','Parcial','Dependência externa','Não comprovado']
        x['status'] = min((f['status'] for f in related), key=precedence.index)
        x['coverage'] = '\n\n'.join(finding_text(f) for f in related)
    elif x['key'] in confirmed:
        x['status'] = 'Implementado'
        x['coverage'] = 'Evidência local conferida para este requisito: ' + '; '.join(confirmed[x['key']]) + '. Testes existentes passaram em 24/09/2026. Não representa aceite da comissão nem conformidade de todo o sistema. Limites de autorização em outros módulos estão nos achados AUD-003/AUD-004.'
        x['audit']['full_acceptance_tested'] = True
    else:
        x['status'] = 'Não comprovado'
        x['coverage'] = (f'AUDITORIA 24/09/2026 — PENDÊNCIA DE COMPROVAÇÃO ITEM A ITEM. O texto integral deste requisito foi preservado e a alegação anterior foi reavaliada como evidência insuficiente para afirmar atendimento integral. '
            f'Não comprovado não significa funcionalidade inexistente. Base de inspeção: {module_files[x["module"]]}. '
            f'AÇÃO NECESSÁRIA: apresentar e executar roteiro específico para {x["key"]}, página impressa {x["page"]}, demonstrando todos os campos, operações, filtros e subitens descritos acima; registrar entrada, resultado esperado e obtido, tela/API e evidência persistida. '
            'Complementar somente as partes que falharem ou não existirem. Referência a tabela, endpoint, teste genérico ou dados seed não basta. '
            'Verificação funcional completa deste item não foi concluída nesta rodada; não contabilizar como aprovado na POC.')
    if transversal.get(x['module']):
        x['coverage'] += '\nDEPENDÊNCIAS TRANSVERSAIS DO MÓDULO: ' + ', '.join(transversal[x['module']]) + '. Pesquise esses códigos nesta página; a demonstração pela interface depende da resolução dos impedimentos documentados.'
    x['coverage'] += '\nReferência documental: ANEXO III.pdf, página física ' + str(x['pdf_page']) + ', impressa ' + str(x['page']) + '. Nenhuma correção funcional executada.'
    audited.append(x)

def edital_assessment(item):
    n = int(item['id'].split('.')[1])
    exact = [f for f in findings if item['id'] in f['clauses']]
    if exact:
        return 'Parcial', '\n\n'.join(finding_text(f) for f in exact)
    if n <= 8:
        return 'Operacional', 'Comprovar treinamento presencial para 30 usuários, início após carga, máximo de 40h e 8h/dia, programa de conteúdos, responsáveis, local e aceites. content.py contém tutoriais textuais; não comprova vídeos EAD, participação ou execução contratual. Exigir registros de frequência e acesso ilimitado ao conteúdo previsto, conforme a cláusula específica.'
    if n == 9:
        return 'Dependência externa', 'Verificação jurídica/institucional não concluída. Exigir documentação e avaliação dos responsáveis quanto às referências expressas no PDF; esta auditoria de software não certifica aderência legal nem verifica alterações legislativas posteriores.'
    if n <= 18:
        return 'Operacional', 'Há chamados, prioridades, prazos e workaround em records.py/domain.py e testes/test_system.py. Isso não comprova equipe, atendimento remoto/presencial, garantia de 90 dias, manutenção preventiva/adaptativa/evolutiva ou prorrogação aceita pela fiscalização. Conferir a cláusula específica com contrato, calendário e evidências de operação. Tabela do PDF: crítico 2h/6h, alto 4h/8h úteis, médio 8h/24h úteis, baixo 24h/48h úteis.'
    if n <= 22:
        return 'Operacional', 'Exigir migração das bases legadas com reconciliação e aceite, início após assinatura, módulos prioritários disponíveis em 30 dias, implantação em 90 dias e eventual prorrogação formal de 30 dias. Não foi apresentada prova de conversão integral, execução paralela e continuidade sem impacto. Cadastro de implantação/OS não comprova execução.'
    if n <= 32:
        return 'Parcial', 'Existem hash de senha, sessões, CSRF, controle de acesso e backup local criptografado. Os achados AUD-003, AUD-004, AUD-005, AUD-006, AUD-018, AUD-021 e AUD-035 impedem declaração global de segurança. Faltam comprovações operacionais de sigilo, transporte, armazenamento, descarte e devolução conforme cada cláusula; verificar contratos, políticas e execução.'
    if n <= 35:
        return 'Não comprovado', 'Interface em português e recursos responsivos existentes. Não foi executada avaliação completa de acessibilidade com tecnologias assistivas, diferentes perfis de usuário, inclusão, adequação institucional e sustentabilidade. Registrar critérios, resultados e correções necessárias por tela.'
    if n <= 52:
        return 'Não comprovado', 'Conferir o requisito transversal integralmente. A matriz antiga possui evidência parcial preservada abaixo; os novos módulos não herdam automaticamente controles dos cadastros antigos. Verificar principalmente permissão por ação, dupla custódia, histórico de todas as operações, ajuda contextual, atualização automática, impressão e assinatura por relatório. Achados gerais AUD-002, AUD-003, AUD-004, AUD-046 e AUD-048.'
    if n == 53:
        return 'Dependência externa', 'Comprovar infraestrutura real, SSD, latência, redundância geográfica, segurança, continuidade e SLA no provedor contratado. AUD-019 a AUD-025 demonstram por que tabelas/indicadores simulados não servem como evidência.'
    if n <= 66:
        return 'Operacional', 'Obrigação contratual/documental: comprovar equipe qualificada, assessoria, manutenção/evolução, OS, atendimento, sustentabilidade e condições de subcontratação conforme o texto exato. Ausência de carta de solidariedade em 4.65 é dispensa documental, não funcionalidade faltante. Subcontratação: observar limite de 25% e autorização expressa indicados no PDF. Ao fim da implantação, 100% dos requisitos devem estar atendidos.'
    if n <= 81:
        return 'Operacional', 'POC não realizada pela comissão nesta auditoria. Aplicar 90% em características gerais e em CADA módulo, 100% em nuvem; item composto só atende se todos os subitens estiverem aptos. Observar fases, prazos, complementação limitada de 2 dias úteis, execução efetiva e gravação/ata conforme a cláusula. O indicador ponderado herdado da tela não pode ser usado para aprovação. Ambiente simulado é permitido; retorno fictício sem execução da função não comprova o requisito.'
    return 'Operacional', 'Condição de garantia contratual externa ao software. Conferir comprovação de 5%, prazo de 10 dias úteis e eventual prorrogação, validade da apólice durante a vigência e 90 dias adicionais, endossos e ausência de lacunas conforme a cláusula. Documentos não apresentados nesta auditoria.'

edital_rows=[]
for i, original in enumerate(edital['items'],1):
    status, assessment = edital_assessment(original)
    edital_rows.append({'key':f'edital.{original["id"]}.p{original["page"]}.{i}', 'module':'Edital · cláusulas 4.1 a 4.86', 'item':original['id'], 'page':original['page'], 'pdf_page':original['page']-34,
        'text':original['text'], 'status':status, 'before':'Registro anterior: '+original['status']+'. '+original['evidence'],
        'coverage':f'AUDITORIA 24/09/2026 — Cláusula {original["id"]}, página impressa {original["page"]}.\n{assessment}\nNenhuma alteração funcional realizada. Escopo: somente páginas 35–48 fornecidas; não é o edital integral.',
        'audit':{'date':now, 'source':'Edital PE 552 2026 Sistema Rio das Ostras-35-48 (2).pdf','full_acceptance_tested':False}})

counts=Counter(x['status'] for x in audited)
module_counts={m:dict(Counter(x['status'] for x in audited if x['module']==m)) for m in catalog['counts']}
junit = ET.parse(ROOT / 'artifacts/auditoria-20260924-tests.xml').getroot()
suites = list(junit.iter('testsuite'))
tests = {k:sum(int(s.get(k,'0')) for s in suites) for k in ['tests','failures','errors','skipped']}
summary = (f'AUDITORIA TÉCNICA 24/09/2026 — CONFORMIDADE INTEGRAL NÃO COMPROVADA. '
    f'Foram incluídos todos os 1.314 registros do catálogo do Anexo III (100 páginas) e {len(edital_rows)} cláusulas do recorte do edital (14 páginas). '
    f'{len(findings)} achados documentados; {tests["tests"]} testes existentes passaram, mas não representam {1314} testes de aceitação. '
    'Há falhas confirmadas por reprodução e outras por inspeção; a validação funcional integral dos itens marcados Não comprovado permanece pendente. '
    f'Situação do Anexo III: {dict(counts)}. '
    'Pesquise AUD- para os achados, um código (ex.: cloud.2) para o requisito, ou EDITAL para as cláusulas, registradas nos campos de cobertura dos requisitos relacionados. '
    'NÃO UTILIZE o percentual e os cartões herdados desta tela como nota da POC: o cálculo antigo dá crédito parcial, não contempla todas as situações da auditoria. '
    'A fórmula foi apenas apontada, não corrigida. Regra do PDF: 90% por módulo e gerais, 100% nuvem, sem contar item incompleto como atendido. '
    'Nenhuma correção ou implementação funcional foi executada. Somente dados da auditoria foram atualizados.')
finding_rows=[]
for i,f in enumerate(findings,1):
    page = next((x['page'] for x in catalog['items'] if x['key'] in f['requirements']), 46)
    finding_rows.append({'key':f['id'],'module':'Auditoria · achados e correções necessárias','item':i,'page':page,
        'text':f'{f["severity"].upper()} — {f["title"]}. Requisitos: '+(', '.join(f['requirements']) or 'Transversal; ver cláusulas e evidências')+'. Edital: '+(', '.join(f['clauses']) or 'Requisito do Anexo III indicado'),
        'status':f['status'], 'before':'Matriz anterior declarava atendimento integral sem demonstrar este impedimento.', 'coverage':finding_text(f), 'audit':{'date':now, 'kind':'finding', 'not_a_tender_requirement':True}})
summary_row={'key':'AUD-000','module':'Auditoria · achados e correções necessárias','item':0,'page':46,'text':'Leia primeiro: escopo, resultado e limites de evidência','status':'Não comprovado','before':'1.314 itens classificados como Implementado.','coverage':summary,'audit':{'date':now,'kind':'summary','not_a_tender_requirement':True}}

# Mantém os 1.314 registros originais; complementos no campo já pesquisável.
by_id = {x['key']: x for x in audited}
for f in findings:
    if not f['requirements']:
        by_id['general.1']['coverage'] += '\n\nACHADO TRANSVERSAL DA AUDITORIA (não integra o texto deste requisito):\n' + finding_text(f)
general_map = {36:2,37:4,38:6,39:7,40:8,41:3,42:9,43:9,44:10,45:5,46:11,47:12,48:13,49:15,50:16,51:17,52:18}
for clause, original in zip(edital_rows, edital['items']):
    n = int(original['id'].split('.')[1])
    target = ('general.'+str(general_map[n])) if n in general_map else ('cloud.1' if n==53 else 'general.4' if n<=8 else 'general.18' if 10<=n<=18 else 'general.16' if 23<=n<=32 or n==9 else 'general.11' if 19<=n<=22 or 54<=n<=66 else 'general.1')
    by_id[target]['coverage'] += f'\n\nEDITAL — {original["id"]}, página {original["page"]} — {clause["status"]}\nTexto da cláusula: {clause["text"]}\n{clause["coverage"]}'
new=dict(old)

new.update(source='Auditoria do ANEXO III.pdf e do recorte do Edital PE 552/2026 (35–48)',note=summary,
    items=audited,
    audit={'date':now,'scope':'Cobertura documental integral do catálogo fornecido; validação funcional por evidências e amostragem, com pendências explicitadas, sem certificação de 100%.',
        'finding_details':findings,'edital_details':edital_rows,'sources':sources,'annex_items':len(audited),'edital_clauses':len(edital_rows),'findings':len(findings),'annex_status_counts':dict(counts),'annex_module_counts':module_counts,'tests':tests,
        'limits':['Somente páginas 35–48 do edital disponibilizadas.','Sem homologação de provedores, bancos e órgãos externos.','Sem prova de carga municipal concorrente, migração e treinamento contratual.','Sem execução funcional completa dos 1.314 itens e de todos os subitens.','Navegação autenticada feita em instalação temporária do mesmo código; no 8080 somente consulta pública de status.','Itens Não comprovado não são considerados ausentes nem aprovados.','Percentual herdado da interface não é nota de conformidade.']})
new['counts']=dict(Counter(x['status'] for x in new['items']))
new['status_counts']=new['counts']
new['module_counts']={m:dict(Counter(x['status'] for x in new['items'] if x['module']==m)) for m in {x['module'] for x in new['items']}}
assert len({x['key'] for x in new['items']}) == len(new['items'])
(ROOT/'docs/anexo-iii-conformidade.json').write_text(json.dumps(new,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(OUT/'findings.json').write_text(json.dumps(findings,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(OUT/'summary.json').write_text(json.dumps(new['audit'],ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
md=['# Auditoria técnica — 24/09/2026','',summary,'','## Escopo e método','',
    'Comparação do código, schemas, interface, testes e alegações anteriores com os PDFs locais. As 100 páginas extraídas do anexo coincidem com a extração prévia. Hashes dos PDFs e dos arquivos inspecionados foram preservados em artifacts/auditoria-20260924. Não foram examinadas páginas do edital fora do recorte fornecido.',
    '', 'Foram executados os 206 testes existentes em bancos temporários; houve duas advertências de depreciação de ldap3/pyasn1. Reproduções negativas estão em probes.json; navegação real em Chromium está em browser.json. A passagem da suíte não certifica os requisitos e alguns testes aceitam simulações.',
    '', 'A matriz anterior foi preservada em original-anexo-iii-conformidade.json; todos os textos originais e páginas foram mantidos. Cada item sem prova integral foi marcado Não comprovado, sem concluir inexistência. Os cinco requisitos gerais com evidência local suficiente continuam Implementado. Nenhuma alteração de regras de negócio, segurança ou interface foi realizada.',
    '', '## Situação documental por módulo','', '| Módulo | Itens | Situações |','|---|---:|---|']
for module,st in module_counts.items():
    md.append(f'| {module} | {sum(st.values())} | '+ '; '.join(f'{k}: {v}' for k,v in st.items())+' |')
md += ['', '## Achados', '']
for f in findings:
    md += [f'### {f["id"]} — {f["severity"]} — {f["title"]}', '', 'Requisitos: '+(', '.join(f['requirements']) or 'transversal')+'. Cláusulas: '+(', '.join(f['clauses']) or 'Anexo III')+'.', '', finding_text(f), '']
md += ['## Cláusulas do recorte do edital','']
for r in edital_rows:
    md += [f'### {r["key"]} — {r["status"]}', '', r['text'], '',r['coverage'],'']
md += ['## Limitações','']+['- '+x for x in new['audit']['limits']]
(ROOT/'docs/AUDITORIA-2026-09-24.md').write_text('\n'.join(md)+'\n',encoding='utf-8')
print(json.dumps({'annex':len(audited),'edital':len(edital_rows),'findings':len(findings),'rows':len(new['items']),'annex_status':dict(counts),'tests':tests},ensure_ascii=False,indent=2))
