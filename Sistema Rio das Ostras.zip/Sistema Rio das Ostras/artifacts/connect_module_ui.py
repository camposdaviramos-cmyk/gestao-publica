﻿from pathlib import Path
import re,json
p=Path('static/index.html');s=p.read_text(encoding='utf-8');s=s.replace('<link rel="stylesheet" href="/static/bi.css">','<link rel="stylesheet" href="/static/bi.css">\n<link rel="stylesheet" href="/static/module-workspace.css">');s=s.replace('<script src="/static/control-ui.js" defer></script>','<script src="/static/module-ui.js" defer></script>\n<script src="/static/control-ui.js" defer></script>');s=s.replace('<script src="/static/bi-ui.js" defer></script>','<script src="/static/bi-ui.js" defer></script>\n<script src="/static/module-forms.js" defer></script>\n<script src="/static/module-actions.js" defer></script>');p.write_text(s,encoding='utf-8')
for mod in ['finance','control','people','social','bi']:
 p=Path(f'static/{mod}-ui.js');s=p.read_text(encoding='utf-8');s=re.sub(r'ModulesUI.escape\(esc\((.*?)\)\)',r'ModulesUI.escape(\1)',s)
 # Native buttons make calendar and notifications keyboard accessible.
 for cls in ['control-notif-item unread','calendar-event-chip']:
  s=re.sub(r'<div class="'+cls+r'"(.*?)</div>',r'<button type="button" class="'+cls+r'"\1</button>',s,flags=re.S)
 p.write_text(s,encoding='utf-8')
p=Path('static/social-ui.js');s=p.read_text(encoding='utf-8');s=s.replace('data-module-click="social-132" ', 'data-module-click="social-132" data-arg0="${ModulesUI.escape(o.id)}" ');p.write_text(s,encoding='utf-8')
p=Path('static/module-actions.js');s=p.read_text(encoding='utf-8');s=s.replace("return alert('Certidões validadas até 31/12/2026.')","return SocialUI.viewOscCertificates(Number(element.dataset.arg0))");p.write_text(s,encoding='utf-8')
p=Path('people_api.py');s=p.read_text(encoding='utf-8').replace('JOIN erp_people_employees e','JOIN people_employees e');p.write_text(s,encoding='utf-8')
p=Path('finance_api.py');s=p.read_text(encoding='utf-8').replace("require('finance', 'read')","require('finance', 'read' if request.method in ('GET', 'HEAD', 'OPTIONS') else 'write')");p.write_text(s,encoding='utf-8')
p=Path('static/module-workspace.css');s=p.read_text(encoding='utf-8').replace('font-size:24px; line-height:1.3','display:block; font-size:24px; line-height:1.3');p.write_text(s,encoding='utf-8')
p=Path('docs/anexo-iii-conformidade.json');d=json.loads(p.read_text(encoding='utf-8'));print(list(d));print(list(d['audit']));print(d['audit']['finding_details'][1]);print(d['items'][0].keys());print(d.get('note'))
d['note']='Auditoria de 24/09/2026: correções em andamento. Prioridade atual: padronização visual e ações de finance, control, people, social e bi. Eventos compatíveis com CSP e requisições com CSRF em validação. Pendências de cálculo, integrações e homologação continuam abertas; nenhuma declaração de conformidade integral.'
d['audit']['ui_remediation']={'status':'Em validação','modules':['finance','control','people','social','bi'],'scope':'Design global, eventos CSP, CSRF, funções ausentes e formulários','evidence':'artifacts/ui-revisao-20260924'}
p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
