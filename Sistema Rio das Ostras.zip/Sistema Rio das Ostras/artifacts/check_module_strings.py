﻿from pathlib import Path
import re
for mod in ['finance','social','bi']:
 s=Path(f'static/{mod}-ui.js').read_text(encoding='utf-8')
 print(mod,sorted(set(re.findall(r'\$\{([a-z]\w*(?:\.[a-zA-Z_]\w*)+)\}',s))))
