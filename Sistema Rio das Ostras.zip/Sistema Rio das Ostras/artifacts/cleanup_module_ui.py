﻿from pathlib import Path
import re
# Remove replaced implementations so controls have one maintained implementation.
forms=Path('static/module-forms.js').read_text(encoding='utf-8')
for mod,obj in [('finance','FinanceUI'),('social','SocialUI'),('bi','BiUI')]:
 p=Path(f'static/{mod}-ui.js');s=p.read_text(encoding='utf-8')
 names=re.findall(obj+r'\.(\w+) =',forms)
 if mod=='bi':names.append('startKioskMode')
 for name in names:
  s,n=re.subn(r'^  '+name+r': function\([^\n]*\) \{.*?^  \},?\n', '',s,flags=re.M|re.S)
 p.write_text(s,encoding='utf-8')
p=Path('static/module-workspace.css');s=p.read_text(encoding='utf-8')+'''
.module-workspace :is(.people-table,.finance-table,.social-table,.control-table) {min-width:680px;overflow-wrap:normal;}
.module-workspace :is(.people-table-wrapper,.table-wrap) {overflow-x:auto;max-width:100%;}
[data-theme=dark] .module-workspace :is(.finance-btn-primary,.social-btn-primary,.bi-btn-primary,.people-btn:not(.secondary):not(.danger)) {color:#102720;}
''';p.write_text(s,encoding='utf-8')
