﻿import json
from pathlib import Path
d=json.loads(Path('docs/anexo-iii-conformidade.json').read_text(encoding='utf-8'))
for f in d['audit']['finding_details']:
 if f['id'] in ['AUD-004','AUD-046','AUD-029']:
  print(f['id'], f['acceptance'], f['action'])
