﻿from pathlib import Path
from urllib.request import urlopen
import hashlib,json
url='http://127.0.0.1:8080/static/module-ui.js'
with urlopen(url,timeout=10) as r: remote=r.read()
local=Path('static/module-ui.js').read_bytes()
assert hashlib.sha256(remote).digest()==hashlib.sha256(local).digest()
assert Path('data/rio.db').is_file()
print('Serviço 8080 serve os arquivos deste workspace; banco local existente.')
