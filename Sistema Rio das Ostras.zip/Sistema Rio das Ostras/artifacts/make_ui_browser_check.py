﻿from pathlib import Path
p=Path('artifacts/auditoria-20260924/browser_audit.py');s=p.read_text(encoding='utf-8');s=s.replace("OUT = Path(__file__).parent", "OUT = ROOT / 'artifacts/ui-revisao-20260924'")
s=s.replace("server = make_server", "with app.app_context():\n        from finance_seed import seed_finance\n        from people_seed import seed_people\n        from social_seed import seed_social\n        from control_seed import seed_control\n        seed_finance(); seed_people(); seed_social(); seed_control(entity_id=1, exercise=2026)\n    server = make_server")
start=s.index("            for route in")
end=s.index('            browser.close()',start)
s=s[:start]+'''            for route in ['finance','control','people','social','bi']:
                page.goto(base + '/#/' + route)
                page.wait_for_selector('.module-workspace')
                page.wait_for_timeout(500)
                entry = {'route':route,'tabs':[]}
                tabs=page.locator(f'.{route}-tab-btn')
                for i in range(tabs.count()):
                    tabs.nth(i).click()
                    page.wait_for_timeout(500)
                    entry['tabs'].append({'name':tabs.nth(i).inner_text(),'active':tabs.nth(i).evaluate("e=>e.classList.contains('active')"),'inline':page.locator('[onclick],[onchange],[onkeyup],[onkeydown]').count()})
                tabs.nth(0).click()
                page.wait_for_timeout(300)
                page.screenshot(path=str(OUT/f'{route}-desktop.png'),full_page=True)
                page.set_viewport_size({'width':390,'height':844})
                page.wait_for_timeout(100)
                entry['mobile_width']=page.evaluate('({scroll:document.documentElement.scrollWidth,viewport:innerWidth})')
                page.screenshot(path=str(OUT/f'{route}-mobile.png'),full_page=True)
                page.set_viewport_size({'width':1440,'height':1000})
                entry['csp']=page.evaluate('window.auditViolations')
                result['routes'].append(entry)
''' + s[end:]
Path('artifacts/ui-revisao-20260924/browser_check.py').write_text(s,encoding='utf-8')
