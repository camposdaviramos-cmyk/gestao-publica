﻿from pathlib import Path
p=Path('static/module-forms.js');s=p.read_text(encoding='utf-8');s=s.replace('  FinanceUI.viewReport =', '''  FinanceUI.loadSiaficAuthModal = () => {
    openModal('Identificação do operador SIAFIC',`<p>A autenticação por CPF e a assinatura do termo ainda precisam de validação. A sessão atual pertence a <strong>${ModulesUI.escape(state.me?.name || 'usuário autenticado')}</strong>.</p><p><a class="button" href="#/annex">Consultar a pendência AUD-005 no Anexo III</a></p>`);
    document.querySelector('#modal a').addEventListener('click',() => closeModal());
  };
  FinanceUI.importLoaIntoPpa = () => postForm('Importar LOA para PPA','/finance/budget/import-loa',[
    id('source_exercise','Exercício de origem'),id('target_exercise','Exercício de destino')
  ]);
  SocialUI.dischargeSheltering = shelterId => postForm('Desligamento do acolhimento',`/social/shelterings/${shelterId}/discharge`,[
    F('reason','Motivo do desligamento','textarea')
  ],() => SocialUI.loadShelterings());
  window.duplicateSiconfiRule = (ruleId,ruleCode) => postForm('Duplicar regra SICONFI','/control/siconfi/rules',[
    F('new_code','Novo código da regra','text',ruleCode+'-V2')
  ],() => switchControlTab('siconfi'),d => ({...d,action:'duplicate',rule_id:ruleId}));
  FinanceUI.viewReport =''');p.write_text(s,encoding='utf-8')
p=Path('tests/test_module_ui_regressions.py');s=p.read_text(encoding='utf-8').replace('import pytest\n','').replace("'/api/people/portal/updates'","'/api/people/portal/update'");p.write_text(s,encoding='utf-8')
