﻿from pathlib import Path
import re,json,shutil
root=Path('.')
out=root/'artifacts/ui-revisao-20260924';out.mkdir(exist_ok=True)
registry=[]
for mod in ['finance','control','people','social','bi']:
 p=root/f'static/{mod}-ui.js';s=p.read_text(encoding='utf-8');shutil.copy2(p,out/p.name)
 # Stable identifiers rather than translated labels determine the selected tab.
 s=re.sub(r'(class="'+mod+r'-tab-btn[^\n]*?)( onclick="(?:FinanceUI|SocialUI|BiUI)\.switchTab\(\x27([^\x27]+)\x27\)")',lambda m:m[1]+' data-tab="'+m[3]+'"'+m[2],s)
 s=s.replace("btn.textContent.toLowerCase().includes(tabName)","btn.dataset.tab === tabName").replace("btn.textContent.toLowerCase().includes(tabName.slice(0, 4))","btn.dataset.tab === tabName").replace("btn.getAttribute('onclick').includes(`'${tabName}'`)","btn.dataset.tab === tabName")
 def event(m):
  event,code=m.groups();key=f'{mod}-{len(registry)}';attrs=[]
  # Interpolated values remain data, never executable JavaScript.
  def arg(n):
   quoted,expr=n.groups();idx=len(attrs);attrs.append(f'data-arg{idx}="${{ModulesUI.escape({expr})}}"')
   return f'element.dataset.arg{idx}' if quoted else f'Number(element.dataset.arg{idx})'
  code=re.sub(r"(')?\$\{(.*?)\}(?(1)')",arg,code)
  code=code.replace('this.value','element.value')
  if code.startswith("if(event.key==="):
   code=code.replace("if(event.key==='Enter') ","if(event.key==='Enter') return ")
  else: code='return '+code
  registry.append(f"  '{key}': (element, event) => {{ {code}; }}")
  return f'data-module-{event}="{key}" '+ ' '.join(attrs)
 s=re.sub(r'on(click|change|keyup|keydown)="([^"]*)"',event,s)
 if mod in ['finance','social','bi']:
  s=re.sub(r'(?m)^(\s*)fetch\(',r'\1return ModulesUI.request(',s)
 if mod=='people':
  start=s.index('        const opts =');end=s.index('\n    }',start)
  s=s[:start]+"        return api(endpoint.replace(/^\\/api/, ''), method, body);"+s[end:]
 # Use the common tokens; decorative emoji do not belong in the module shell.
 s=re.sub('[\U0001F000-\U0001FAFF\u2600-\u27BF\uFE0F\u200D]+ ?','',s)
 s=s.replace('var(--ink-muted, #64748b)','var(--muted)').replace('var(--ink-muted)','var(--muted)')
 s=s.replace(f'<div class="{mod}-container">',f'<div class="{mod}-container module-workspace">')
 s=s.replace('<h1><span class="icon"></span>','<h1>')
 p.write_text(s,encoding='utf-8')
(root/'static/module-actions.js').write_text('/* Explicit CSP-safe event bindings for the five administrative modules. */\nModulesUI.bind({\n'+',\n'.join(registry)+'\n});\n',encoding='utf-8')
print('Converted event handlers:',len(registry))
# Missing controls are tracked explicitly for implementation, not hidden.
for mod in ['finance','people','social','bi']:
 s=(root/f'static/{mod}-ui.js').read_text(encoding='utf-8')
 calls=set(re.findall(r'(?:'+mod.title()+r'UI\.)?(\w+)\(', '\n'.join(r for r in registry if "'"+mod+'-' in r)))
 defs=set(re.findall(r'(\w+): function|window\.(\w+) = (?:async )?function',s))
 print(mod, sorted(calls-set(sum((list(t) for t in defs),[]))-{'Number','getElementById','if'}))
