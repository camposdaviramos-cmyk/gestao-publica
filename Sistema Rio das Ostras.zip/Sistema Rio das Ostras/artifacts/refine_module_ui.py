﻿from pathlib import Path
p=Path('static/module-forms.js');s=p.read_text(encoding='utf-8').replace("  const today = () => new Date().toISOString().slice(0,10);\n",'')
s=s.replace("dashboard_code:BiUI.currentTab,filters:{exercise:BiUI.currentExercise}","dashboard_code:({lrf:'DASH-EXEC-LRF',cash:'DASH-FINANCEIRO',funnel:'DASH-FINANCEIRO',hr:'DASH-PESSOAL',procurement:'DASH-COMPRAS',assets:'DASH-PATRIMONIO',person360:'DASH-CIDADAO-360'})[BiUI.currentTab] || BiUI.currentTab,filters:{exercise:BiUI.currentExercise,tab:BiUI.currentTab}")
s=s.replace('})();', '''  BiUI.toggleKioskMode = async () => {
    if (document.getElementById('bi-kiosk-view')) return BiUI.exitKioskMode();
    const cfg=await api('/bi/kiosk/slides');
    const renderers={EXECUTIVE_LRF:'renderLrfTab',FINANCEIRO:'renderCashTab',PESSOAS:'renderHrTab',COMPRAS:'renderProcurementTab',PATRIMONIO:'renderAssetsTab'};
    const slides=(cfg.slides || []).filter(slide => renderers[slide.area]);
    if (!slides.length) throw new Error('Nenhum painel disponível para projeção. Cadastre os painéis do BI.');
    const banner=document.createElement('div');
    banner.id='bi-kiosk-view'; banner.className='bi-kiosk-banner';
    banner.innerHTML='<div class="bi-kiosk-header"><h1 id="bi-kiosk-title"></h1><button class="button" id="bi-kiosk-exit">Sair do modo TV (Esc)</button></div><div id="bi-kiosk-content"></div>';
    document.body.append(banner);
    document.getElementById('bi-kiosk-exit').addEventListener('click',() => BiUI.exitKioskMode());
    let index=0;
    const advance=async () => {
      const slide=slides[index++ % slides.length];
      const content=document.getElementById('bi-kiosk-content');
      if (!content) return;
      document.getElementById('bi-kiosk-title').textContent=slide.title;
      try {await BiUI[renderers[slide.area]](content);}
      catch(error) {content.textContent=error.message;}
      if (document.getElementById('bi-kiosk-view')) BiUI.kioskInterval=setTimeout(advance,Math.max(5,slide.duration || cfg.rotation_interval_seconds || 15)*1000);
    };
    await advance();
  };
})();''')
p.write_text(s,encoding='utf-8')
p=Path('static/finance-ui.js');s=p.read_text(encoding='utf-8').replace('<div class="finance-grid" style="margin-bottom: 1.5rem;">','<div class="finance-grid module-kpis" style="margin-bottom: 1.5rem;">');p.write_text(s,encoding='utf-8')
p=Path('static/module-workspace.css');s=p.read_text(encoding='utf-8')+'\n@media(min-width:1200px) {.module-workspace .module-kpis {grid-template-columns:repeat(4,minmax(0,1fr));}}\n';p.write_text(s,encoding='utf-8')
