﻿from pathlib import Path
import re
p=Path('static/module-forms.js');s=p.read_text(encoding='utf-8').replace("F('reason','Motivo do desligamento','textarea')","date('discharge_date','Data do desligamento'),F('discharge_reason','Motivo do desligamento','textarea')")
s=s.replace("],null,d => ({...d,amount_cents:Math.round(d.amount*100)}));\n  FinanceUI.renderAccountability", "],() => FinanceUI.loadAdvanceFunds(),d => ({...d,amount_cents:Math.round(d.amount*100)}));\n  FinanceUI.renderAccountability")
s=s.replace("],null,d => ({fund_id:d.fund_id,spent_cents:Math.round(d.spent*100),returned_cents:Math.round(d.returned*100)}));", "],() => FinanceUI.loadAdvanceFunds(),d => ({fund_id:d.fund_id,spent_cents:Math.round(d.spent*100),returned_cents:Math.round(d.returned*100)}));")
s=s.replace('  FinanceUI.viewReport =', '''  FinanceUI.loadAdvanceFunds = async () => {
    const body=document.getElementById('finance-advance-body');
    if (!body) return;
    try {
      const rows=await api('/finance/treasury/advance-funds');
      const e=ModulesUI.escape;
      body.innerHTML=rows.length ? rows.map(row => `<tr><td>${e(row.request_number)}</td><td>${e(row.server_name)}</td><td>${e(row.advance_type)}</td><td>${e(row.commitment_id)}</td><td>${(row.amount_cents/100).toLocaleString('pt-BR',{style:'currency',currency:'BRL'})}</td><td>${e(row.due_date)}</td><td>${e(row.status)}</td><td>${row.status==='Aberto' ? `<button class="finance-btn-secondary" data-module-click="finance-44" data-arg0="${row.id}">Prestar Contas</button>` : 'Concluído'}</td></tr>`).join('') : '<tr><td colspan="8">Nenhum adiantamento cadastrado.</td></tr>';
    } catch(error) {body.innerHTML=`<tr><td colspan="8">${ModulesUI.escape(error.message)}</td></tr>`;}
  };
  FinanceUI.viewReport =''')
p.write_text(s,encoding='utf-8')
p=Path('static/finance-ui.js');s=p.read_text(encoding='utf-8');s=re.sub(r'<tbody>\s*<tr>\s*<td>SUP-202601001</td>.*?</tbody>', '<tbody id="finance-advance-body"><tr><td colspan="8">Carregando adiantamentos...</td></tr></tbody>',s,flags=re.S)
s=s.replace('          <table class="finance-table">','          <div class="table-wrap"><table class="finance-table">').replace('          </table>\n        </div>','          </table></div>\n        </div>')
s=s.replace("  postRender: function() {", "  postRender: function() {\n    if (this.currentTab === 'tesouraria') this.loadAdvanceFunds();")
s=re.sub(r'\n{4,}','\n\n',s);p.write_text(s,encoding='utf-8')
p=Path('static/module-actions.js');s=p.read_text(encoding='utf-8').replace('FinanceUI.renderAccountability(1)','FinanceUI.renderAccountability(Number(element.dataset.arg0))');p.write_text(s,encoding='utf-8')
p=Path('finance_api.py');s=p.read_text(encoding='utf-8').replace("        return jsonify(query_chronological_payments())\n    data", "        from db import get_db\n        rows = get_db().execute('SELECT * FROM finance_advance_funds ORDER BY id DESC').fetchall()\n        return jsonify([dict(row) for row in rows])\n    data");p.write_text(s,encoding='utf-8')
p=Path('finance_core.py');s=p.read_text(encoding='utf-8');needle='    receipt_num = f"REC-PRESTACAO-{fund_id}-{datetime.now().strftime(\'%Y%m%d\')}"';s=s.replace(needle,'''    fund = db.execute('SELECT amount_cents, status FROM finance_advance_funds WHERE id=?', (fund_id,)).fetchone()
    if not fund:
        from auth import ApiError
        raise ApiError('Adiantamento não encontrado.', 404)
    if fund['status'] != 'Aberto':
        from auth import ApiError
        raise ApiError('A prestação de contas deste adiantamento já foi concluída.', 409)
    if spent_cents < 0 or returned_cents < 0 or spent_cents + returned_cents != fund['amount_cents']:
        from auth import ApiError
        raise ApiError('Os valores utilizado e devolvido devem totalizar o adiantamento.')
'''+needle);p.write_text(s,encoding='utf-8')
p=Path('static/module-workspace.css');s=p.read_text(encoding='utf-8');lines=s.splitlines();seen=set();out=[]
for line in lines:
 if line.startswith(('.module-workspace :is(.people-table','[data-theme=dark]')):
  if line in seen:continue
  seen.add(line)
 out.append(line)
p.write_text('\n'.join(out)+'\n',encoding='utf-8')
