/**
 * Módulo de Assistência Social e Cidadania (SUAS / CRAS / CREAS / CadÚnico) - Frontend
 * Sistema Integrado Rio das Ostras - Edital PE 552/2026 & Anexo III (410 Itens)
 */

window.SocialUI = {
  currentTab: 'familias',
  selectedFamilyId: null,

  render: function(targetEl) {
    if (!targetEl) targetEl = document.getElementById('main') || document.getElementById('app');
    targetEl.innerHTML = `
      <div class="social-container">
        <header class="social-header">
          <div>
            <h1><span class="icon">🤝</span> Assistência Social & Cidadania (SUAS)</h1>
            <p style="margin: 0.25rem 0 0 0; color: var(--ink-muted, #64748b); font-size: 0.9rem;">
              CRAS, CREAS, Centro POP, Prontuário SUAS 360º, RMA Oficial MDS, Benefícios Eventuais, IVS, Habitação e MROSC
            </p>
          </div>
          <div style="display: flex; gap: 0.5rem;">
            <button class="social-btn-secondary" onclick="SocialUI.openNewFamilyModal()">➕ Nova Família</button>
            <button class="social-btn-primary" onclick="SocialUI.refresh()">🔄 Atualizar</button>
          </div>
        </header>

        <nav class="social-nav-tabs">
          <button class="social-tab-btn ${this.currentTab === 'familias' ? 'active' : ''}" onclick="SocialUI.switchTab('familias')">👨‍👩‍👧‍👦 Famílias & Prontuário</button>
          <button class="social-tab-btn ${this.currentTab === 'rma' ? 'active' : ''}" onclick="SocialUI.switchTab('rma')">📑 RMA Oficial (MDS)</button>
          <button class="social-tab-btn ${this.currentTab === 'beneficios' ? 'active' : ''}" onclick="SocialUI.switchTab('beneficios')">📦 Benefícios & Estoque</button>
          <button class="social-tab-btn ${this.currentTab === 'acolhimento' ? 'active' : ''}" onclick="SocialUI.switchTab('acolhimento')">🏠 Acolhimento & Mulher (Sigilo)</button>
          <button class="social-tab-btn ${this.currentTab === 'habitacao' ? 'active' : ''}" onclick="SocialUI.switchTab('habitacao')">🏘️ Habitação & IVS</button>
          <button class="social-tab-btn ${this.currentTab === 'mrosc' ? 'active' : ''}" onclick="SocialUI.switchTab('mrosc')">🤝 MROSC (OSCs Parceiras)</button>
          <button class="social-tab-btn ${this.currentTab === 'territorios' ? 'active' : ''}" onclick="SocialUI.switchTab('territorios')">🗺️ Mapa de Calor & Diagnóstico</button>
        </nav>

        <main id="social-tab-content">
          ${this.renderTabContent()}
        </main>
      </div>
    `;
    this.postRender();
  },

  switchTab: function(tabName) {
    this.currentTab = tabName;
    const contentEl = document.getElementById('social-tab-content');
    if (contentEl) {
      contentEl.innerHTML = this.renderTabContent();
      this.postRender();
    }
    // Atualiza classes dos botões
    document.querySelectorAll('.social-tab-btn').forEach(btn => {
      btn.classList.toggle('active', btn.textContent.toLowerCase().includes(tabName.slice(0, 4)));
    });
  },

  refresh: function() {
    this.switchTab(this.currentTab);
  },

  renderTabContent: function() {
    switch (this.currentTab) {
      case 'familias': return this.renderFamiliasTab();
      case 'rma': return this.renderRmaTab();
      case 'beneficios': return this.renderBeneficiosTab();
      case 'acolhimento': return this.renderAcolhimentoTab();
      case 'habitacao': return this.renderHabitacaoTab();
      case 'mrosc': return this.renderMroscTab();
      case 'territorios': return this.renderTerritoriosTab();
      default: return '<div class="social-card">Aba em desenvolvimento.</div>';
    }
  },

  // ── 1. ABA FAMÍLIAS & PRONTUÁRIO SUAS ──
  renderFamiliasTab: function() {
    return `
      <div class="social-metrics-grid" id="social-family-metrics">
        <div class="social-metric-card">
          <span class="social-metric-title">Famílias Cadastradas</span>
          <span class="social-metric-value" id="metric-total-fam">...</span>
          <span class="social-metric-subtitle">Base Prontuário / CadÚnico</span>
        </div>
        <div class="social-metric-card">
          <span class="social-metric-title">Extrema Pobreza</span>
          <span class="social-metric-value" style="color: #dc2626;" id="metric-extrema-fam">...</span>
          <span class="social-metric-subtitle">Renda per capita ≤ R$ 109,00</span>
        </div>
        <div class="social-metric-card">
          <span class="social-metric-title">Famílias com PCD</span>
          <span class="social-metric-value" style="color: #0284c7;" id="metric-pcd-fam">...</span>
          <span class="social-metric-subtitle">Atenção Prioritária SUAS</span>
        </div>
        <div class="social-metric-card">
          <span class="social-metric-title">Área de Risco</span>
          <span class="social-metric-value" style="color: #ea580c;" id="metric-risco-fam">...</span>
          <span class="social-metric-subtitle">Vulnerabilidade Habitacional</span>
        </div>
      </div>

      <div class="social-card">
        <div class="social-card-header">
          <h3><span>👥</span> Prontuário Eletrônico Familiar (SUAS 360º)</h3>
          <div style="display: flex; gap: 0.5rem;">
            <input type="text" id="social-family-search" placeholder="Buscar por Nome, NIS ou CPF..." style="padding: 0.4rem 0.75rem; border-radius: 6px; border: 1px solid var(--line); font-size: 0.9rem;" onkeyup="if(event.key==='Enter') SocialUI.searchFamilies()">
            <button class="social-btn-primary" onclick="SocialUI.searchFamilies()">🔍 Filtrar</button>
          </div>
        </div>

        <div style="overflow-x: auto;">
          <table class="social-table">
            <thead>
              <tr>
                <th>Código / NIS</th>
                <th>Responsável Familiar</th>
                <th>Bairro / Território</th>
                <th>Renda Total / Per Capita</th>
                <th>Faixa / IVS</th>
                <th>Completude</th>
                <th>Ações</th>
              </tr>
            </thead>
            <tbody id="social-families-tbody">
              <tr><td colspan="7" style="text-align: center;">Carregando prontuários familiares...</td></tr>
            </tbody>
          </table>
        </div>
      </div>

      <div id="social-family-drawer" style="display: none; margin-top: 1rem;"></div>
    `;
  },

  // ── 2. ABA RMA OFICIAL (CRAS / CREAS / CENTRO POP) ──
  renderRmaTab: function() {
    return `
      <div class="social-card">
        <div class="social-card-header">
          <h3><span>📑</span> Registro Mensal de Atendimento Oficial (MDS / Censo SUAS)</h3>
          <div style="display: flex; gap: 0.5rem; align-items: center;">
            <select id="rma-unit-select" onchange="SocialUI.loadRma()" style="padding: 0.4rem; border-radius: 6px; border: 1px solid var(--line);">
              <option value="1">CRAS Central - Jardim Campomar</option>
              <option value="2">CRAS Sul - Cidade Beiramar</option>
              <option value="4">CREAS Extensão do Bosque</option>
              <option value="5">Centro POP Âncora</option>
            </select>
            <select id="rma-month-select" onchange="SocialUI.loadRma()" style="padding: 0.4rem; border-radius: 6px; border: 1px solid var(--line);">
              <option value="1">Janeiro / 2026</option>
              <option value="2">Fevereiro / 2026</option>
              <option value="3">Março / 2026</option>
            </select>
            <button class="social-btn-primary" onclick="SocialUI.exportRmaXml()">📥 Baixar XML Oficial MDS</button>
          </div>
        </div>

        <div id="rma-content-display">
          <div style="text-align: center; padding: 2rem;">Carregando dados do RMA...</div>
        </div>
      </div>
    `;
  },

  // ── 3. ABA BENEFÍCIOS EVENTUAIS & ALMOXARIFADO ──
  renderBeneficiosTab: function() {
    return `
      <div class="social-card" style="margin-bottom: 1rem;">
        <div class="social-card-header">
          <h3><span>📦</span> Estoque de Insumos & Benefícios Eventuais</h3>
          <button class="social-btn-primary" onclick="SocialUI.openNewStockBatchModal()">➕ Entrada de Estoque</button>
        </div>
        <div style="overflow-x: auto;">
          <table class="social-table">
            <thead>
              <tr>
                <th>Código</th>
                <th>Insumo / Benefício</th>
                <th>Categoria</th>
                <th>Estoque Atual</th>
                <th>Mínimo</th>
                <th>Lotes Ativos</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody id="social-supplies-tbody">
              <tr><td colspan="7" style="text-align: center;">Carregando almoxarifado socioassistencial...</td></tr>
            </tbody>
          </table>
        </div>
      </div>

      <div class="social-card">
        <div class="social-card-header">
          <h3><span>🎁</span> Histórico de Concessões de Benefícios Eventuais (LOAS)</h3>
          <button class="social-btn-primary" onclick="SocialUI.openGrantBenefitModal()">✍️ Nova Concessão com Parecer CRESS</button>
        </div>
        <div style="overflow-x: auto;">
          <table class="social-table">
            <thead>
              <tr>
                <th>Data</th>
                <th>Família / NIS</th>
                <th>Tipo Benefício</th>
                <th>Insumo Fornecido</th>
                <th>Parecer Técnico</th>
                <th>Assistente Social (CRESS)</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody id="social-benefits-tbody">
              <tr><td colspan="7" style="text-align: center;">Carregando concessões...</td></tr>
            </tbody>
          </table>
        </div>
      </div>
    `;
  },

  // ── 4. ABA ACOLHIMENTO & MULHER (SIGILO ESTRITO) ──
  renderAcolhimentoTab: function() {
    return `
      <div class="social-card" style="margin-bottom: 1rem;">
        <div class="social-card-header">
          <h3><span>🏠</span> Vagas de Acolhimento Institucional (Crianças, Idosos e Famílias)</h3>
          <button class="social-btn-primary" onclick="SocialUI.openNewShelteringModal()">➕ Admissão em Acolhimento</button>
        </div>
        <div style="overflow-x: auto;">
          <table class="social-table">
            <thead>
              <tr>
                <th>Unidade</th>
                <th>Acolhido</th>
                <th>Data Admissão</th>
                <th>Motivo / Processo Judicial</th>
                <th>Leito</th>
                <th>Responsável Técnico</th>
                <th>Ações</th>
              </tr>
            </thead>
            <tbody id="social-shelterings-tbody">
              <tr><td colspan="7" style="text-align: center;">Carregando acolhimentos...</td></tr>
            </tbody>
          </table>
        </div>
      </div>

      <div class="social-card">
        <div class="social-card-header">
          <h3><span>🛡️</span> Atendimento com Sigilo Estrito a Mulheres em Situação de Violência (Lei Maria da Penha)</h3>
          <button class="social-btn-primary" onclick="SocialUI.openViolenceRecordModal()">🔒 Registrar Atendimento Sigiloso</button>
        </div>
        <p style="font-size: 0.85rem; color: var(--ink-muted); margin-bottom: 1rem;">
          Conforme Resolução CFESS nº 493/06 e Lei 11.340/06, os dados de identificação e endereços de mulheres abrigadas são criptografados sob sigilo funcional restrito aos profissionais CRESS/CRP.
        </p>
        <div style="background: var(--paper); border: 1px solid var(--line); border-radius: 8px; padding: 1rem;">
          <strong>Protocolo Ativo de Proteção Municipal:</strong> Casa Abrigo Viva Mulher com vaga e alimentação garantidas, botão de pânico integrado à Guarda Municipal e acompanhamento psicossocial contínuo.
        </div>
      </div>
    `;
  },

  // ── 5. ABA HABITAÇÃO DE INTERESSE SOCIAL & IVS ──
  renderHabitacaoTab: function() {
    return `
      <div class="social-card" style="margin-bottom: 1rem;">
        <div class="social-card-header">
          <h3><span>🏘️</span> Conjuntos Habitacionais Municipais de Interesse Social</h3>
        </div>
        <div style="overflow-x: auto;">
          <table class="social-table">
            <thead>
              <tr>
                <th>Programa</th>
                <th>Conjunto Habitacional</th>
                <th>Bairro</th>
                <th>Total Unidades</th>
                <th>Disponíveis</th>
                <th>Cota Idoso (3%)</th>
                <th>Cota PCD (3%)</th>
                <th>Ações</th>
              </tr>
            </thead>
            <tbody id="social-complexes-tbody">
              <tr><td colspan="8" style="text-align: center;">Carregando conjuntos habitacionais...</td></tr>
            </tbody>
          </table>
        </div>
      </div>

      <div class="social-card">
        <div class="social-card-header">
          <h3><span>📊</span> Classificação Habitacional & Ranking de Contemplados</h3>
          <button class="social-btn-primary" onclick="SocialUI.openNewHousingAppModal()">📝 Nova Inscrição Habitacional</button>
        </div>
        <div id="housing-ranking-container">
          <p style="color: var(--ink-muted);">Selecione um conjunto habitacional para visualizar a classificação com cotas aplicadas.</p>
        </div>
      </div>
    `;
  },

  // ── 6. ABA MROSC (OSCS PARCEIRAS LEI 13.019/14) ──
  renderMroscTab: function() {
    return `
      <div class="social-card" style="margin-bottom: 1rem;">
        <div class="social-card-header">
          <h3><span>🤝</span> Organizações da Sociedade Civil (MROSC - Lei 13.019/2014)</h3>
          <button class="social-btn-primary" onclick="SocialUI.openNewOscModal()">➕ Cadastrar OSC</button>
        </div>
        <div style="overflow-x: auto;">
          <table class="social-table">
            <thead>
              <tr>
                <th>CNPJ</th>
                <th>Razão Social / Nome Fantasia</th>
                <th>Representante Legal</th>
                <th>Certidões</th>
                <th>Status Cadastral</th>
                <th>Ações</th>
              </tr>
            </thead>
            <tbody id="social-oscs-tbody">
              <tr><td colspan="6" style="text-align: center;">Carregando OSCs parceiras...</td></tr>
            </tbody>
          </table>
        </div>
      </div>

      <div class="social-card">
        <div class="social-card-header">
          <h3><span>📑</span> Termos de Parceria & Prestações de Contas Mensais</h3>
        </div>
        <div style="overflow-x: auto;">
          <table class="social-table">
            <thead>
              <tr>
                <th>Instrumento</th>
                <th>OSC Parceira</th>
                <th>Objeto</th>
                <th>Valor Global</th>
                <th>Conta Vinculada</th>
                <th>Vigência</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody id="social-mrosc-contracts-tbody">
              <tr><td colspan="7" style="text-align: center;">Carregando parcerias MROSC...</td></tr>
            </tbody>
          </table>
        </div>
      </div>
    `;
  },

  // ── 7. ABA MAPA DE CALOR & DIAGNÓSTICO TERRITORIAL ──
  renderTerritoriosTab: function() {
    return `
      <div class="social-card" style="margin-bottom: 1rem;">
        <div class="social-card-header">
          <h3><span>🗺️</span> Mapa de Calor Georreferenciado de Vulnerabilidades (IVS)</h3>
          <button class="social-btn-primary" onclick="SocialUI.loadHeatmap()">🔄 Recarregar Pontos</button>
        </div>
        <div class="social-heatmap-box" id="heatmap-container">
          <p style="font-weight: 600; color: var(--ink);">Diagnóstico Geográfico de Rio das Ostras - RJ</p>
          <p style="font-size: 0.85rem; color: var(--ink-muted);">Densidade ponderada por extrema pobreza e Índice de Vulnerabilidade Social.</p>
          <div class="social-heatmap-grid" id="heatmap-neighborhoods-grid">
            <!-- Células geradas via JS -->
          </div>
        </div>
      </div>

      <div class="social-card">
        <div class="social-card-header">
          <h3><span>📍</span> Abrangência dos Bairros e Cobertura CRAS</h3>
        </div>
        <div style="overflow-x: auto;">
          <table class="social-table">
            <thead>
              <tr>
                <th>Bairro / Distrito</th>
                <th>Unidade CRAS de Referência</th>
                <th>Área de Risco</th>
                <th>IVS Médio</th>
                <th>Famílias Cadastradas</th>
              </tr>
            </thead>
            <tbody id="social-territories-tbody">
              <tr><td colspan="5" style="text-align: center;">Carregando territórios...</td></tr>
            </tbody>
          </table>
        </div>
      </div>
    `;
  },

  // ── PÓS-RENDERIZAÇÃO E CARGA DE DADOS VIA API ──
  postRender: function() {
    if (this.currentTab === 'familias') {
      this.loadFamilies();
      this.loadFamilyMetrics();
    } else if (this.currentTab === 'rma') {
      this.loadRma();
    } else if (this.currentTab === 'beneficios') {
      this.loadSupplies();
      this.loadBenefits();
    } else if (this.currentTab === 'acolhimento') {
      this.loadShelterings();
    } else if (this.currentTab === 'habitacao') {
      this.loadComplexes();
    } else if (this.currentTab === 'mrosc') {
      this.loadOscs();
      this.loadOscContracts();
    } else if (this.currentTab === 'territorios') {
      this.loadHeatmap();
      this.loadTerritories();
    }
  },

  loadFamilyMetrics: function() {
    fetch('/api/social/diagnosis')
      .then(r => r.json())
      .then(d => {
        const setTxt = (id, val) => { const el = document.getElementById(id); if (el) el.textContent = val; };
        setTxt('metric-total-fam', d.total_families || 0);
        setTxt('metric-extrema-fam', d.extrema_pobreza || 0);
        setTxt('metric-pcd-fam', d.pcd_families || 0);
        setTxt('metric-risco-fam', d.risk_zone_families || 0);
      });
  },

  loadFamilies: function(q) {
    const url = q ? `/api/social/families?q=${encodeURIComponent(q)}` : '/api/social/families';
    fetch(url)
      .then(r => r.json())
      .then(data => {
        const tbody = document.getElementById('social-families-tbody');
        if (!tbody) return;
        if (!data || data.length === 0) {
          tbody.innerHTML = '<tr><td colspan="7" style="text-align: center;">Nenhuma família encontrada.</td></tr>';
          return;
        }
        tbody.innerHTML = data.map(f => `
          <tr>
            <td><strong>${f.family_code}</strong><br><small style="color: var(--ink-muted);">${f.head_nis}</small></td>
            <td><strong>${f.head_name}</strong><br><small>${f.head_cpf || 'CPF não informado'}</small></td>
            <td>${f.neighborhood} (${f.cras_unit_name || 'CRAS'})</td>
            <td>R$ ${f.total_income.toFixed(2)}<br><small style="color: var(--ink-muted);">R$ ${f.per_capita_income.toFixed(2)} / pessoa</small></td>
            <td>
              <span class="social-badge ${f.income_bracket === 'EXTREMA_POBREZA' ? 'extrema' : f.income_bracket === 'POBREZA' ? 'pobreza' : 'baixa'}">
                ${f.income_bracket}
              </span>
              <br><small>IVS: ${f.ivs_score.toFixed(2)} (${f.ivs_level})</small>
            </td>
            <td>
              <div style="background: var(--paper); border-radius: 4px; overflow: hidden; width: 60px; height: 8px;">
                <div style="background: #10b981; width: ${f.cadastral_completeness_pct}%; height: 100%;"></div>
              </div>
              <small>${f.cadastral_completeness_pct}%</small>
            </td>
            <td>
              <button class="social-btn-secondary" style="padding: 0.25rem 0.5rem; font-size: 0.8rem;" onclick="SocialUI.viewFamily(${f.id})">🔍 Prontuário</button>
            </td>
          </tr>
        `).join('');
      });
  },

  searchFamilies: function() {
    const q = document.getElementById('social-family-search')?.value;
    this.loadFamilies(q);
  },

  viewFamily: function(fid) {
    fetch(`/api/social/families/${fid}`)
      .then(r => r.json())
      .then(d => {
        const drawer = document.getElementById('social-family-drawer');
        if (!drawer) return;
        const f = d.family;
        drawer.style.display = 'block';
        drawer.innerHTML = `
          <div class="social-card" style="border-left: 4px solid var(--accent);">
            <div class="social-card-header">
              <h3><span>📋</span> Prontuário SUAS 360º — ${f.head_name} (Código: ${f.family_code})</h3>
              <button class="social-btn-secondary" onclick="document.getElementById('social-family-drawer').style.display='none'">Fechar</button>
            </div>
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 1rem; margin-bottom: 1rem;">
              <div><strong>NIS Responsável:</strong> ${f.head_nis}</div>
              <div><strong>CPF:</strong> ${f.head_cpf || 'Não informado'}</div>
              <div><strong>Endereço:</strong> ${f.address}, ${f.neighborhood}</div>
              <div><strong>Unidade de Referência:</strong> ${f.cras_unit_name || 'CRAS'}</div>
              <div><strong>Renda Familiar:</strong> R$ ${f.total_income.toFixed(2)}</div>
              <div><strong>Renda per capita:</strong> R$ ${f.per_capita_income.toFixed(2)}</div>
              <div><strong>Classificação IVS:</strong> ${f.ivs_score} (${f.ivs_level})</div>
              <div><strong>Completude Cadastral:</strong> ${f.cadastral_completeness_pct}%</div>
            </div>

            <h4>Membros Familiares (${d.members.length})</h4>
            <table class="social-table" style="margin-bottom: 1rem;">
              <thead>
                <tr><th>Nome</th><th>Parentesco</th><th>Nascimento</th><th>PCD</th><th>SCFV</th></tr>
              </thead>
              <tbody>
                ${d.members.map(m => `
                  <tr>
                    <td>${m.name}</td>
                    <td>${m.kinship}</td>
                    <td>${m.birth_date}</td>
                    <td>${m.is_pcd ? 'Sim (PCD)' : 'Não'}</td>
                    <td>${m.scfv_enrolled ? 'Inscrito' : 'Não'}</td>
                  </tr>
                `).join('')}
              </tbody>
            </table>

            <h4>Histórico de Benefícios Eventuais Concedidos</h4>
            <table class="social-table">
              <thead>
                <tr><th>Data</th><th>Tipo</th><th>Parecer do Técnico</th><th>Assistente Social</th><th>Status</th></tr>
              </thead>
              <tbody>
                ${d.benefits.length ? d.benefits.map(b => `
                  <tr>
                    <td>${b.request_date ? b.request_date.slice(0, 10) : ''}</td>
                    <td>${b.benefit_type}</td>
                    <td>${b.technical_opinion}</td>
                    <td>${b.social_worker_name} (CRESS ${b.social_worker_cress})</td>
                    <td><span class="social-badge regular">${b.status}</span></td>
                  </tr>
                `).join('') : '<tr><td colspan="5" style="text-align: center;">Nenhum benefício registrado.</td></tr>'}
              </tbody>
            </table>
          </div>
        `;
        drawer.scrollIntoView({ behavior: 'smooth' });
      });
  },

  // ── CARGA DO RMA ──
  loadRma: function() {
    const uid = document.getElementById('rma-unit-select')?.value || 1;
    const month = document.getElementById('rma-month-select')?.value || 1;
    fetch(`/api/social/rma/cras?unit_id=${uid}&year=2026&month=${month}`)
      .then(r => r.json())
      .then(rma => {
        const disp = document.getElementById('rma-content-display');
        if (!disp) return;
        disp.innerHTML = `
          <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 1rem; margin-top: 1rem;">
            <div style="background: var(--paper); border: 1px solid var(--line); border-radius: 8px; padding: 1rem;">
              <h4 style="margin: 0 0 0.5rem 0; color: var(--accent);">Bloco I: Acompanhamento PAIF</h4>
              <p>Famílias em Acompanhamento: <strong>${rma.paif_total_active}</strong></p>
              <p>Novas Famílias no Mês: <strong>${rma.paif_new_inserted}</strong></p>
              <p>Famílias em Extrema Pobreza: <strong>${rma.paif_extreme_poverty}</strong></p>
              <p>Beneficiárias do Bolsa Família: <strong>${rma.paif_bolsa_familia}</strong></p>
            </div>
            <div style="background: var(--paper); border: 1px solid var(--line); border-radius: 8px; padding: 1rem;">
              <h4 style="margin: 0 0 0.5rem 0; color: var(--accent);">Bloco II: Atendimentos & Ações</h4>
              <p>Atendimentos Individualizados: <strong>${rma.atendimentos_total}</strong></p>
              <p>Visitas Domiciliares: <strong>${rma.visitas_domiciliares}</strong></p>
              <p>Reuniões Coletivas PAIF: <strong>${rma.reunioes_coletivas_paif}</strong></p>
            </div>
            <div style="background: var(--paper); border: 1px solid var(--line); border-radius: 8px; padding: 1rem;">
              <h4 style="margin: 0 0 0.5rem 0; color: var(--accent);">Bloco III: Benefícios Eventuais</h4>
              <p>Auxílio Natalidade: <strong>${rma.beneficios_natalidade}</strong></p>
              <p>Auxílio Funeral: <strong>${rma.beneficios_funeral}</strong></p>
              <p>Outros Benefícios (Cestas): <strong>${rma.beneficios_outros}</strong></p>
            </div>
          </div>
          <div style="margin-top: 1.5rem; display: flex; justify-content: space-between; align-items: center; border-top: 1px solid var(--line); padding-top: 1rem;">
            <span>Status do Mês: <strong style="color: #059669;">${rma.status}</strong></span>
            ${rma.status === 'ABERTO' ? `
              <button class="social-btn-primary" onclick="SocialUI.closeRmaMonth(${uid}, 2026, ${month})">🔒 Homologar e Fechar RMA</button>
            ` : '<span class="social-badge regular">Fechado e Pronto para o Censo SUAS</span>'}
          </div>
        `;
      });
  },

  exportRmaXml: function() {
    const uid = document.getElementById('rma-unit-select')?.value || 1;
    const month = document.getElementById('rma-month-select')?.value || 1;
    window.open(`/api/social/rma/cras/export-xml?unit_id=${uid}&year=2026&month=${month}`, '_blank');
  },

  closeRmaMonth: function(uid, year, month) {
    if (!confirm("Confirma o fechamento oficial do RMA para o Ministério do Desenvolvimento Social?")) return;
    fetch('/api/social/rma/cras/close', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({ unit_id: uid, year: year, month: month })
    })
    .then(r => r.json())
    .then(() => {
      alert("RMA fechado e XML oficial gerado com sucesso!");
      SocialUI.loadRma();
    });
  },

  // ── ESTOQUE & BENEFÍCIOS ──
  loadSupplies: function() {
    fetch('/api/social/supplies')
      .then(r => r.json())
      .then(data => {
        const tbody = document.getElementById('social-supplies-tbody');
        if (!tbody) return;
        tbody.innerHTML = data.map(s => `
          <tr>
            <td><strong>${s.code}</strong></td>
            <td>${s.name}</td>
            <td>${s.category}</td>
            <td><strong>${s.current_stock} ${s.unit_of_measure}</strong></td>
            <td>${s.minimum_stock} ${s.unit_of_measure}</td>
            <td><span class="social-badge regular">Ativo</span></td>
            <td>
              <span class="social-badge ${s.current_stock < s.minimum_stock ? 'extrema' : 'regular'}">
                ${s.current_stock < s.minimum_stock ? 'Estoque Baixo' : 'Normal'}
              </span>
            </td>
          </tr>
        `).join('');
      });
  },

  loadBenefits: function() {
    fetch('/api/social/benefits')
      .then(r => r.json())
      .then(data => {
        const tbody = document.getElementById('social-benefits-tbody');
        if (!tbody) return;
        tbody.innerHTML = data.map(b => `
          <tr>
            <td>${b.request_date ? b.request_date.slice(0, 10) : ''}</td>
            <td><strong>${b.head_name}</strong><br><small>${b.family_code}</small></td>
            <td>${b.benefit_type}</td>
            <td>${b.supply_name || 'Auxílio Financeiro'}</td>
            <td>${b.technical_opinion}</td>
            <td>${b.social_worker_name} (CRESS ${b.social_worker_cress})</td>
            <td><span class="social-badge regular">${b.status}</span></td>
          </tr>
        `).join('');
      });
  },

  // ── ACOLHIMENTO ──
  loadShelterings: function() {
    fetch('/api/social/shelterings')
      .then(r => r.json())
      .then(data => {
        const tbody = document.getElementById('social-shelterings-tbody');
        if (!tbody) return;
        tbody.innerHTML = data.map(s => `
          <tr>
            <td><strong>${s.unit_name}</strong></td>
            <td><strong>${s.resident_name}</strong><br><small>${s.resident_cpf_nis || 'Não informado'}</small></td>
            <td>${s.admission_date}</td>
            <td>${s.reason}<br><small style="color: var(--ink-muted);">${s.judicial_process_number || 'Sem determinação judicial'}</small></td>
            <td>${s.bed_number}</td>
            <td>${s.responsible_technician}</td>
            <td>
              <button class="social-btn-secondary" style="padding: 0.2rem 0.5rem; font-size: 0.8rem;" onclick="SocialUI.dischargeSheltering(${s.id})">Desligar</button>
            </td>
          </tr>
        `).join('');
      });
  },

  dischargeSheltering: function(sid) {
    const reason = prompt("Motivo do desligamento (ex: Reintegração familiar, transferência, autonomia):");
    if (!reason) return;
    fetch(`/api/social/shelterings/${sid}/discharge`, {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({ discharge_date: new Date().toISOString().slice(0, 10), discharge_reason: reason })
    })
    .then(r => r.json())
    .then(() => {
      alert("Desligamento registrado com sucesso!");
      SocialUI.loadShelterings();
    });
  },

  // ── HABITAÇÃO ──
  loadComplexes: function() {
    fetch('/api/social/housing/complexes')
      .then(r => r.json())
      .then(data => {
        const tbody = document.getElementById('social-complexes-tbody');
        if (!tbody) return;
        tbody.innerHTML = data.map(c => `
          <tr>
            <td><strong>${c.program_title}</strong></td>
            <td>${c.name}</td>
            <td>${c.neighborhood}</td>
            <td>${c.total_units}</td>
            <td><strong style="color: #059669;">${c.available_units}</strong></td>
            <td>${c.reserved_elderly_quota} vagas</td>
            <td>${c.reserved_pcd_quota} vagas</td>
            <td>
              <button class="social-btn-primary" style="padding: 0.2rem 0.5rem; font-size: 0.8rem;" onclick="SocialUI.viewHousingRanking(${c.program_id}, ${c.id})">Ver Ranking</button>
            </td>
          </tr>
        `).join('');
      });
  },

  viewHousingRanking: function(pid, cid) {
    fetch(`/api/social/housing/ranking?program_id=${pid}&complex_id=${cid}`)
      .then(r => r.json())
      .then(d => {
        const container = document.getElementById('housing-ranking-container');
        if (!container) return;
        container.innerHTML = `
          <div style="margin-bottom: 1rem; display: flex; gap: 1rem;">
            <div>Unidades Ofertadas: <strong>${d.total_available}</strong></div>
            <div>Contemplados: <strong style="color: #059669;">${d.contemplated_count}</strong></div>
            <div>Cotas Atendidas: <strong>${d.elderly_quota_met} Idosos</strong> / <strong>${d.pcd_quota_met} PCDs</strong></div>
          </div>
          <table class="social-table">
            <thead>
              <tr><th>Posição</th><th>Nº Inscrição</th><th>Pontuação Final</th><th>Cota</th><th>Status</th></tr>
            </thead>
            <tbody>
              ${d.ranking.map(r => `
                <tr>
                  <td><strong>#${r.ranking_position}</strong></td>
                  <td>${r.application_number}</td>
                  <td><strong>${r.final_points} pontos</strong></td>
                  <td><span class="social-badge ${r.special_quota === 'GERAL' ? 'baixa' : 'alerta'}">${r.special_quota}</span></td>
                  <td><span class="social-badge ${r.status === 'CONTEMPLADO' ? 'regular' : 'baixa'}">${r.status}</span></td>
                </tr>
              `).join('')}
            </tbody>
          </table>
        `;
      });
  },

  // ── MROSC ──
  loadOscs: function() {
    fetch('/api/social/oscs')
      .then(r => r.json())
      .then(data => {
        const tbody = document.getElementById('social-oscs-tbody');
        if (!tbody) return;
        tbody.innerHTML = data.map(o => `
          <tr>
            <td><strong>${o.cnpj}</strong></td>
            <td>${o.corporate_name}<br><small style="color: var(--ink-muted);">${o.trade_name || ''}</small></td>
            <td>${o.legal_representative}</td>
            <td><span class="social-badge regular">CNDs Regulares</span></td>
            <td><span class="social-badge regular">${o.registration_status}</span></td>
            <td>
              <button class="social-btn-secondary" style="padding: 0.2rem 0.5rem; font-size: 0.8rem;" onclick="alert('Certidões validadas até 31/12/2026.')">Ver Certidões</button>
            </td>
          </tr>
        `).join('');
      });
  },

  loadOscContracts: function() {
    fetch('/api/social/oscs/contracts')
      .then(r => r.json())
      .then(data => {
        const tbody = document.getElementById('social-mrosc-contracts-tbody');
        if (!tbody) return;
        tbody.innerHTML = data.map(c => `
          <tr>
            <td><strong>${c.contract_number}</strong><br><small>${c.partnership_type}</small></td>
            <td>${c.corporate_name}</td>
            <td>${c.plan_title}</td>
            <td><strong>R$ ${c.global_value.toFixed(2)}</strong></td>
            <td><small>${c.dedicated_bank_account}</small></td>
            <td>${c.start_date} até ${c.end_date}</td>
            <td><span class="social-badge regular">${c.status}</span></td>
          </tr>
        `).join('');
      });
  },

  // ── MAPA DE CALOR & TERRITÓRIOS ──
  loadHeatmap: function() {
    fetch('/api/social/heatmap')
      .then(r => r.json())
      .then(data => {
        const grid = document.getElementById('heatmap-neighborhoods-grid');
        if (!grid) return;
        const neighMap = {};
        data.points.forEach(p => {
          if (!neighMap[p.neighborhood]) neighMap[p.neighborhood] = { count: 0, sumWeight: 0, level: p.level };
          neighMap[p.neighborhood].count++;
          neighMap[p.neighborhood].sumWeight += p.weight;
        });

        grid.innerHTML = Object.keys(neighMap).map(n => {
          const item = neighMap[n];
          const avg = (item.sumWeight / item.count).toFixed(2);
          const cls = avg > 0.6 ? 'alta' : avg > 0.35 ? 'media' : 'baixa';
          return `
            <div class="social-heatmap-cell ${cls}">
              <strong>${n}</strong><br>
              <small>Famílias: ${item.count}</small><br>
              <small>IVS Médio: ${avg}</small>
            </div>
          `;
        }).join('');
      });
  },

  loadTerritories: function() {
    fetch('/api/social/territories')
      .then(r => r.json())
      .then(data => {
        const tbody = document.getElementById('social-territories-tbody');
        if (!tbody) return;
        tbody.innerHTML = data.map(t => `
          <tr>
            <td><strong>${t.name}</strong> (${t.district})</td>
            <td>${t.cras_unit_name || 'CRAS Central'}</td>
            <td>${t.high_risk_zone ? '<span class="social-badge extrema">Sim</span>' : 'Não'}</td>
            <td>${t.vulnerability_index_avg}</td>
            <td><strong>${t.families_count}</strong></td>
          </tr>
        `).join('');
      });
  },

  // ── MODAIS DE CADASTRO ──
  openNewFamilyModal: function() {
    const code = 'FAM-RO-' + Math.floor(100000 + Math.random() * 900000);
    const nis = '1' + Math.floor(1000000000 + Math.random() * 9000000000);
    const name = prompt("Nome do Responsável Familiar:", "Benedita dos Santos");
    if (!name) return;
    const cpf = prompt("CPF do Responsável:", "022.333.444-55");
    const neigh = prompt("Bairro de Residência (ex: Âncora, Praiamar, Jardim Campomar):", "Âncora");
    const inc = prompt("Renda Familiar Total (R$):", "400.00");
    const members = prompt("Quantidade de Membros na Família:", "3");

    fetch('/api/social/families', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({
        family_code: code,
        head_nis: nis,
        head_name: name,
        head_cpf: cpf,
        head_birth_date: '1988-06-15',
        address: 'Rua Principal, 100',
        neighborhood: neigh || 'Centro',
        cras_unit_id: 1,
        total_income: parseFloat(inc || 0),
        members_count: parseInt(members || 1),
        housing_risk_zone: 0,
        female_headed: 1,
        has_elderly: 0,
        has_pcd: 0
      })
    })
    .then(r => r.json())
    .then(d => {
      alert(`Família ${d.family.family_code} cadastrada com sucesso!\nFaixa: ${d.family.income_bracket}\nIVS: ${d.family.ivs_score} (${d.family.ivs_level})`);
      SocialUI.loadFamilies();
      SocialUI.loadFamilyMetrics();
    });
  },

  openGrantBenefitModal: function() {
    const fid = prompt("ID da Família Beneficiária:", "1");
    if (!fid) return;
    const reason = prompt("Parecer do Assistente Social:", "Insegurança alimentar temporária identificada em visita domiciliar.");
    fetch('/api/social/benefits', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({
        family_id: parseInt(fid),
        benefit_type: 'CESTA_BASICA',
        supply_id: 1,
        batch_id: 1,
        quantity: 1,
        technical_opinion: reason || 'Parecer de concessão de emergência',
        social_worker_cress: '34567',
        social_worker_name: 'Fernanda de Souza'
      })
    })
    .then(r => r.json())
    .then(d => {
      alert(`Benefício eventual #${d.id} concedido e baixado do estoque do almoxarifado!`);
      SocialUI.loadBenefits();
      SocialUI.loadSupplies();
    });
  },

  openNewShelteringModal: function() {
    const name = prompt("Nome completo da pessoa a acolher:", "Carlos Alberto Mendes");
    if (!name) return;
    const reason = prompt("Motivo do acolhimento:", "Situação de vulnerabilidade extrema / abandono");
    fetch('/api/social/shelterings', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({
        unit_id: 6, // Unidade de Acolhimento
        resident_name: name,
        reason: reason || 'Acolhimento Emergencial',
        responsible_technician: 'Assistente Social de Plantão'
      })
    })
    .then(r => r.json())
    .then(d => {
      alert(`Acolhimento registrado! Leito: ${d.bed_number}`);
      SocialUI.loadShelterings();
    });
  },

  openViolenceRecordModal: function() {
    const initials = prompt("Iniciais da mulher vítima de violência (ex: M.R.S.):", "J.S.M.");
    if (!initials) return;
    const bo = prompt("Número do Boletim de Ocorrência (B.O.):", "BO-128/2026-128DP");
    fetch('/api/social/violence', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({
        victim_initials: initials,
        age: 32,
        has_children: 1,
        police_report_number: bo,
        protective_measure_granted: 1,
        violence_types: 'FISICA,PSICOLOGICA',
        aggressor_relationship: 'Ex-companheiro',
        shelter_required: 1,
        technician_cress_crp: 'CRESS 38712-RJ'
      })
    })
    .then(r => r.json())
    .then(d => {
      alert(`Atendimento sigiloso registrado sob código restrito: ${d.secret_code}`);
    });
  },

  openNewHousingAppModal: function() {
    const fid = prompt("ID da Família no Prontuário:", "1");
    if (!fid) return;
    fetch('/api/social/housing/applications', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({
        program_id: 1,
        complex_id: 1,
        family_id: parseInt(fid),
        manual_points: 0
      })
    })
    .then(r => r.json())
    .then(d => {
      alert(`Inscrição habitacional ${d.application_number} realizada!\nPontuação Final: ${d.final_points} pontos\nCota: ${d.special_quota}`);
      SocialUI.viewHousingRanking(1, 1);
    });
  },

  openNewStockBatchModal: function() {
    const batch = prompt("Número do Lote:", "LOTE-2026-03");
    if (!batch) return;
    const qty = prompt("Quantidade recebida:", "50");
    fetch('/api/social/stock/batches', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({
        warehouse_id: 1,
        supply_id: 1,
        batch_number: batch,
        quantity: parseInt(qty || 10),
        expiration_date: '2027-01-01',
        supplier_name: 'Fornecedor Registrado Rio das Ostras'
      })
    })
    .then(r => r.json())
    .then(() => {
      alert("Entrada de estoque realizada com sucesso!");
      SocialUI.loadSupplies();
    });
  },

  openNewOscModal: function() {
    const cnpj = prompt("CNPJ da Organização da Sociedade Civil:", "12.345.678/0001-99");
    if (!cnpj) return;
    const name = prompt("Razão Social da OSC:", "Instituto Social Rio das Ostras Viva");
    const rep = prompt("Nome do Representante Legal:", "Dra. Claudia Ramos");
    fetch('/api/social/oscs', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({
        cnpj: cnpj,
        corporate_name: name || 'Instituto Social',
        legal_representative: rep || 'Presidente',
        representative_cpf: '123.456.789-00'
      })
    })
    .then(r => r.json())
    .then(d => {
      alert(`OSC ${d.corporate_name} cadastrada com regularidade aprovada!`);
      SocialUI.loadOscs();
    });
  }
};

// ── Interceptação da Página ERP para Assistência Social ──
(function() {
  const originalErpPage = window.erpPage;
  window.erpPage = async function(module) {
    if (module === 'social') {
      setTimeout(() => {
        const main = document.getElementById('main');
        if (main) SocialUI.render(main);
      }, 50);
      return '<div class="loading-panel"><div class="loader"></div>Carregando Assistência Social, CRAS, CREAS e CadÚnico...</div>';
    }
    return originalErpPage ? await originalErpPage(module) : '';
  };
})();
