/**
 * Módulo Financeiro, Contábil, Orçamentário e Tesouraria - Frontend
 * Sistema Integrado Rio das Ostras - Edital PE 552/2026 & Anexo III (229 Itens)
 */

window.FinanceUI = {
  currentTab: 'contabilidade',

  render: function(targetEl) {
    if (!targetEl) targetEl = document.getElementById('main') || document.getElementById('app');
    targetEl.innerHTML = `
      <div class="finance-container">
        <header class="finance-header">
          <div>
            <h1><span class="icon">💼</span> Gestão Financeira, Orçamentária e Contabilidade</h1>
            <p style="margin: 0.25rem 0 0 0; color: var(--ink-muted, #64748b); font-size: 0.9rem;">
              SIAFIC (Dec. 10.540/20), PCASP, SICONFI MSC, EFD-Reinf, PPA/LDO/LOA, LRF, Tesouraria e Conciliação OFX
            </p>
          </div>
          <div style="display: flex; gap: 0.5rem;">
            <button class="finance-btn-secondary" onclick="FinanceUI.loadSiaficAuthModal()">🔐 Acesso SIAFIC (CPF)</button>
            <button class="finance-btn-primary" onclick="FinanceUI.refresh()">🔄 Atualizar</button>
          </div>
        </header>

        <nav class="finance-nav-tabs">
          <button class="finance-tab-btn ${this.currentTab === 'contabilidade' ? 'active' : ''}" onclick="FinanceUI.switchTab('contabilidade')">📊 Contabilidade & SIAFIC</button>
          <button class="finance-tab-btn ${this.currentTab === 'reinf' ? 'active' : ''}" onclick="FinanceUI.switchTab('reinf')">📑 EFD-Reinf (Fiscal)</button>
          <button class="finance-tab-btn ${this.currentTab === 'planejamento' ? 'active' : ''}" onclick="FinanceUI.switchTab('planejamento')">📈 Planejamento & Orçamento</button>
          <button class="finance-tab-btn ${this.currentTab === 'lrf' ? 'active' : ''}" onclick="FinanceUI.switchTab('lrf')">⚖️ LRF & Limites</button>
          <button class="finance-tab-btn ${this.currentTab === 'tesouraria' ? 'active' : ''}" onclick="FinanceUI.switchTab('tesouraria')">🏦 Tesouraria & Conciliação OFX</button>
        </nav>

        <main id="finance-tab-content">
          ${this.renderTabContent()}
        </main>
      </div>
    `;
    this.postRender();
  },

  switchTab: function(tabName) {
    this.currentTab = tabName;
    const contentEl = document.getElementById('finance-tab-content');
    if (contentEl) {
      contentEl.innerHTML = this.renderTabContent();
      this.postRender();
    }
    // Update active tab button style
    document.querySelectorAll('.finance-tab-btn').forEach(btn => {
      btn.classList.toggle('active', btn.textContent.toLowerCase().includes(tabName));
    });
  },

  refresh: function() {
    this.switchTab(this.currentTab);
    if (window.toast) window.toast('Dados do módulo financeiro atualizados.');
  },

  renderTabContent: function() {
    switch (this.currentTab) {
      case 'contabilidade':
        return this.renderContabilidadeTab();
      case 'reinf':
        return this.renderReinfTab();
      case 'planejamento':
        return this.renderPlanejamentoTab();
      case 'lrf':
        return this.renderLrfTab();
      case 'tesouraria':
        return this.renderTesourariaTab();
      default:
        return `<p>Aba não encontrada.</p>`;
    }
  },

  renderContabilidadeTab: function() {
    return `
      <div class="finance-grid" style="margin-bottom: 1.5rem;">
        <div class="finance-card">
          <div class="finance-card-title">Orçamento Atualizado</div>
          <div class="finance-stat-value">R$ 865.000.000,00</div>
          <div class="finance-stat-label">Exercício Vigente: 2026</div>
        </div>
        <div class="finance-card">
          <div class="finance-card-title">Despesa Empenhada Líquida</div>
          <div class="finance-stat-value" style="color: #0284c7;">R$ 830.000.000,00</div>
          <div class="finance-stat-label">95,95% do orçamento fixado</div>
        </div>
        <div class="finance-card">
          <div class="finance-card-title">Despesa Liquidada</div>
          <div class="finance-stat-value" style="color: #059669;">R$ 808.000.000,00</div>
          <div class="finance-stat-label">Saldo a liquidar: R$ 22.000.000,00</div>
        </div>
        <div class="finance-card">
          <div class="finance-card-title">Superávit Financeiro Apurado</div>
          <div class="finance-stat-value" style="color: #10b981;">R$ 120.000.000,00</div>
          <div class="finance-stat-label">Ativo Financeiro - Passivo Financeiro</div>
        </div>
      </div>

      <div class="finance-grid">
        <div class="finance-card" style="grid-column: span 2;">
          <div class="finance-card-title">
            <span>Escrituração Contábil em Tempo Real (Livro Diário)</span>
            <button class="finance-btn-primary" onclick="FinanceUI.openNewJournalModal()">+ Novo Lançamento</button>
          </div>
          <div style="overflow-x: auto;">
            <table class="finance-table" id="finance-journal-table">
              <thead>
                <tr>
                  <th>Nº</th>
                  <th>Data</th>
                  <th>Fato Contábil</th>
                  <th>Conta Débito</th>
                  <th>Conta Crédito</th>
                  <th>Valor (R$)</th>
                  <th>Atributo</th>
                  <th>Ações</th>
                </tr>
              </thead>
              <tbody id="finance-journal-body">
                <tr><td colspan="8" style="text-align: center;">Carregando lançamentos contábeis…</td></tr>
              </tbody>
            </table>
          </div>
        </div>

        <div class="finance-card">
          <div class="finance-card-title">Demonstrações DCASP e Legais</div>
          <div style="display: flex; flex-direction: column; gap: 0.5rem;">
            <button class="finance-btn-secondary" onclick="FinanceUI.viewReport('anexo1')">📄 Anexo 1 - Receita e Despesa (Lei 4.320/64)</button>
            <button class="finance-btn-secondary" onclick="FinanceUI.viewReport('anexo12')">📊 Anexo 12 - Balanço Orçamentário</button>
            <button class="finance-btn-secondary" onclick="FinanceUI.viewReport('anexo13')">💵 Anexo 13 - Balanço Financeiro</button>
            <button class="finance-btn-secondary" onclick="FinanceUI.viewReport('anexo14')">🏢 Anexo 14 - Balanço Patrimonial</button>
            <button class="finance-btn-secondary" onclick="FinanceUI.viewReport('anexo15')">📉 Anexo 15 - DVP (Variações Patrimoniais)</button>
            <button class="finance-btn-secondary" onclick="FinanceUI.viewReport('anexo18')">🌊 Anexo 18 - DFC (Fluxos de Caixa)</button>
            <button class="finance-btn-secondary" onclick="FinanceUI.viewReport('law9452')">🏛️ Liberação de Recursos (Lei 9.452/97)</button>
            <button class="finance-btn-secondary" onclick="FinanceUI.viewReport('art29a')">🏛️ Duodécimo Câmara (Art. 29-A CF)</button>
            <button class="finance-btn-secondary" onclick="FinanceUI.exportMscFile()">🌐 Gerar Matriz MSC SICONFI (XBRL/CSV)</button>
          </div>
        </div>
      </div>
    `;
  },

  renderReinfTab: function() {
    return `
      <div class="finance-grid" style="margin-bottom: 1.5rem;">
        <div class="finance-card">
          <div class="finance-card-title">Contribuinte EFD-Reinf</div>
          <div style="font-size: 1.1rem; font-weight: 600;">Prefeitura Municipal de Rio das Ostras</div>
          <div style="color: var(--ink-muted); font-size: 0.85rem; margin-top: 0.25rem;">CNPJ: 29.184.000/0001-00 · Classif. 99 (Órgão Público)</div>
          <span class="finance-badge finance-badge-success" style="margin-top: 0.5rem;">Certificado A1 Válido</span>
        </div>
        <div class="finance-card">
          <div class="finance-card-title">Retenções Apuradas no Mês</div>
          <div class="finance-stat-value">R$ 1.850.000,00</div>
          <div class="finance-stat-label">Competência Atual: 2026-01</div>
        </div>
        <div class="finance-card">
          <div class="finance-card-title">Eventos Transmitidos à RFB</div>
          <div class="finance-stat-value" style="color: #10b981;">100%</div>
          <div class="finance-stat-label">R-1000, R-2010 e R-4020 Processados</div>
        </div>
      </div>

      <div class="finance-card">
        <div class="finance-card-title">
          <span>Notas Fiscais e RPS ABRASF com Retenção na Fonte (Tabela 06)</span>
          <button class="finance-btn-primary" onclick="FinanceUI.openNewReinfInvoiceModal()">+ Registrar Nota Fiscal / RPS</button>
        </div>
        <table class="finance-table">
          <thead>
            <tr>
              <th>NF / RPS</th>
              <th>Credor</th>
              <th>Serviço (Tab 06)</th>
              <th>Valor Bruto (R$)</th>
              <th>Base Retenção (R$)</th>
              <th>Alíquota</th>
              <th>Retenção (R$)</th>
              <th>Status IPC 11</th>
            </tr>
          </thead>
          <tbody id="finance-reinf-body">
            <tr>
              <td>NF 4821</td>
              <td>Construtora Guanabara Ltda</td>
              <td>01.07 - Limpeza e Conservação</td>
              <td>R$ 450.000,00</td>
              <td>R$ 450.000,00</td>
              <td>11%</td>
              <td><strong>R$ 49.500,00</strong></td>
              <td><span class="finance-badge finance-badge-success">Extraorçamentário Gerado</span></td>
            </tr>
            <tr>
              <td>NF 9102</td>
              <td>Segurança Integrada Costa do Sol</td>
              <td>11.02 - Vigilância e Segurança</td>
              <td>R$ 128.000,00</td>
              <td>R$ 128.000,00</td>
              <td>11%</td>
              <td><strong>R$ 14.080,00</strong></td>
              <td><span class="finance-badge finance-badge-success">Extraorçamentário Gerado</span></td>
            </tr>
          </tbody>
        </table>
        <div class="finance-actions" style="margin-top: 1rem;">
          <button class="finance-btn-primary" onclick="FinanceUI.transmitReinfEvent('R-2010')">🚀 Transmitir Lote R-2010 (Serviços Tomados)</button>
          <button class="finance-btn-secondary" onclick="FinanceUI.transmitReinfEvent('R-4020')">🚀 Transmitir Lote R-4020 (Retenções PJ)</button>
          <button class="finance-btn-secondary" onclick="FinanceUI.transmitReinfEvent('R-4099')">🔒 Fechamento da Competência (R-4099)</button>
        </div>
      </div>
    `;
  },

  renderPlanejamentoTab: function() {
    return `
      <div class="finance-grid" style="margin-bottom: 1.5rem;">
        <div class="finance-card">
          <div class="finance-card-title">PPA Quadrienal</div>
          <div class="finance-stat-value">2026-2029</div>
          <div class="finance-stat-label">Planejamento Estratégico Municipal</div>
        </div>
        <div class="finance-card">
          <div class="finance-card-title">LDO Anual</div>
          <div class="finance-stat-value">2026</div>
          <div class="finance-stat-label">Diretrizes Orçamentárias e Metas Fiscais</div>
        </div>
        <div class="finance-card">
          <div class="finance-card-title">LOA Anual</div>
          <div class="finance-stat-value">R$ 865 M</div>
          <div class="finance-stat-label">Orçamento Geral do Município</div>
        </div>
      </div>

      <div class="finance-grid">
        <div class="finance-card">
          <div class="finance-card-title">Projeção Percentual das Estimativas (PPA / LDO)</div>
          <p style="font-size: 0.85rem; color: var(--ink-muted);">Projeta estimativas de receita ou metas de ações antes de efetivar nas peças legais.</p>
          <div class="finance-form-group">
            <label>Peça Orçamentária</label>
            <select class="finance-select" id="proj-piece">
              <option value="PPA">Plano Plurianual (PPA)</option>
              <option value="LDO">Lei de Diretrizes Orçamentárias (LDO)</option>
            </select>
          </div>
          <div class="finance-form-group">
            <label>Percentual de Reajuste (%)</label>
            <input type="number" class="finance-input" id="proj-rate" value="5.5" step="0.1">
          </div>
          <button class="finance-btn-primary" onclick="FinanceUI.runProjectionPreview()">🔍 Simular Projeção</button>
          <button class="finance-btn-secondary" onclick="FinanceUI.importLoaIntoPpa()" style="margin-left: 0.5rem;">📥 Importar LOA -> PPA</button>
          <div id="proj-results" style="margin-top: 1rem; font-size: 0.85rem;"></div>
        </div>

        <div class="finance-card">
          <div class="finance-card-title">Decretos de Alteração Orçamentária</div>
          <p style="font-size: 0.85rem; color: var(--ink-muted);">Gera minutas formatadas de Decretos de Crédito Suplementar / Especial.</p>
          <div class="finance-form-group">
            <label>Número do Decreto</label>
            <input type="text" class="finance-input" id="decree-num" value="3.455/2026">
          </div>
          <div class="finance-form-group">
            <label>Tipo de Crédito</label>
            <select class="finance-select" id="decree-type">
              <option value="Suplementar">Suplementar</option>
              <option value="Especial">Especial</option>
              <option value="Extraordinario">Extraordinário</option>
            </select>
          </div>
          <div class="finance-form-group">
            <label>Valor (R$)</label>
            <input type="number" class="finance-input" id="decree-amt" value="2500000">
          </div>
          <div class="finance-form-group">
            <label>Justificativa Legal</label>
            <input type="text" class="finance-input" id="decree-just" value="Reforço de dotações orçamentárias da Secretaria Municipal de Saúde">
          </div>
          <button class="finance-btn-primary" onclick="FinanceUI.generateDecree()">📝 Gerar Decreto Formatado</button>
        </div>
      </div>
    `;
  },

  renderLrfTab: function() {
    return `
      <div class="finance-grid" style="margin-bottom: 1.5rem;">
        <div class="finance-card">
          <div class="finance-card-title">Educação Básica (MDE)</div>
          <div class="finance-stat-value" style="color: #10b981;">27,00%</div>
          <div class="finance-stat-label">Mínimo Constitucional: 25,00% (Cumprido)</div>
        </div>
        <div class="finance-card">
          <div class="finance-card-title">FUNDEB (Magistério)</div>
          <div class="finance-stat-value" style="color: #10b981;">75,00%</div>
          <div class="finance-stat-label">Mínimo Constitucional: 70,00% (Cumprido)</div>
        </div>
        <div class="finance-card">
          <div class="finance-card-title">Saúde (Ações e Serviços)</div>
          <div class="finance-stat-value" style="color: #10b981;">16,00%</div>
          <div class="finance-stat-label">Mínimo Constitucional: 15,00% (Cumprido)</div>
        </div>
        <div class="finance-card">
          <div class="finance-card-title">Despesa com Pessoal (LRF)</div>
          <div class="finance-stat-value" style="color: #d97706;">49,68%</div>
          <div class="finance-stat-label">Alerta: 48,6% | Máx: 54,0% (Em Alerta)</div>
        </div>
      </div>

      <div class="finance-card">
        <div class="finance-card-title">Demonstrativos Oficiais da LRF (MDF 14ª Edição STN)</div>
        <div class="finance-grid" style="grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));">
          <div>
            <h4 style="margin: 0 0 0.5rem 0; color: var(--ink);">RREO (Bimestral)</h4>
            <div style="display: flex; flex-direction: column; gap: 0.25rem;">
              <button class="finance-btn-secondary" onclick="FinanceUI.viewLrf('rreo', 1)">Anexo 1 - Balanço Orçamentário</button>
              <button class="finance-btn-secondary" onclick="FinanceUI.viewLrf('rreo', 2)">Anexo 2 - Despesa Função/Subfunção</button>
              <button class="finance-btn-secondary" onclick="FinanceUI.viewLrf('rreo', 3)">Anexo 3 - Receita Corrente Líquida</button>
              <button class="finance-btn-secondary" onclick="FinanceUI.viewLrf('rreo', 6)">Anexo 6 - Resultado Primário e Nominal</button>
              <button class="finance-btn-secondary" onclick="FinanceUI.viewLrf('rreo', 8)">Anexo 8 - MDE (Educação)</button>
              <button class="finance-btn-secondary" onclick="FinanceUI.viewLrf('rreo', 12)">Anexo 12 - ASPS (Saúde)</button>
            </div>
          </div>
          <div>
            <h4 style="margin: 0 0 0.5rem 0; color: var(--ink);">RGF (Quadrimestral)</h4>
            <div style="display: flex; flex-direction: column; gap: 0.25rem;">
              <button class="finance-btn-secondary" onclick="FinanceUI.viewLrf('rgf', 1)">Anexo 1 - Despesa com Pessoal</button>
              <button class="finance-btn-secondary" onclick="FinanceUI.viewLrf('rgf', 2)">Anexo 2 - Dívida Consolidada Líquida</button>
              <button class="finance-btn-secondary" onclick="FinanceUI.viewLrf('rgf', 3)">Anexo 3 - Garantias e Contragarantias</button>
              <button class="finance-btn-secondary" onclick="FinanceUI.viewLrf('rgf', 5)">Anexo 5 - Disponibilidade de Caixa / RP</button>
              <button class="finance-btn-secondary" onclick="FinanceUI.viewLrf('rgf', 6)">Anexo 6 - Demonstrativo Simplificado</button>
            </div>
          </div>
          <div>
            <h4 style="margin: 0 0 0.5rem 0; color: var(--ink);">Exportações Externas</h4>
            <div style="display: flex; flex-direction: column; gap: 0.25rem;">
              <button class="finance-btn-secondary" onclick="FinanceUI.exportManad()">📁 Exportar MANAD Previdenciário</button>
              <button class="finance-btn-secondary" onclick="FinanceUI.exportSigfis()">🏛️ Exportar SIGFIS TCE-RJ</button>
            </div>
          </div>
        </div>
      </div>
    `;
  },

  renderTesourariaTab: function() {
    return `
      <div class="finance-grid" style="margin-bottom: 1.5rem;">
        <div class="finance-card">
          <div class="finance-card-title">Saldo Disponível em Bancos</div>
          <div class="finance-stat-value">R$ 140.000.000,00</div>
          <div class="finance-stat-label">Contas BB, Caixa, Santander, Bradesco</div>
        </div>
        <div class="finance-card">
          <div class="finance-card-title">Conciliação Bancária OFX</div>
          <div class="finance-stat-value" style="color: #10b981;">100%</div>
          <div class="finance-stat-label">Nenhum movimento pendente de ajuste</div>
        </div>
        <div class="finance-card">
          <div class="finance-card-title">Ordens Bancárias Eletrônicas</div>
          <div class="finance-stat-value" style="color: #0284c7;">CNAB 240 / PIX</div>
          <div class="finance-stat-label">Banco do Brasil S.A. Ativo</div>
        </div>
      </div>

      <div class="finance-grid">
        <div class="finance-card">
          <div class="finance-card-title">
            <span>Ordens Bancárias e Pagamentos (OBE / PIX BB)</span>
            <button class="finance-btn-primary" onclick="FinanceUI.generateObeBatch()">+ Gerar Lote OBE</button>
          </div>
          <p style="font-size: 0.85rem; color: var(--ink-muted);">Emissão de remessas e estorno automático de pagamentos rejeitados pelo banco.</p>
          <div style="display: flex; gap: 0.5rem; margin-top: 1rem;">
            <button class="finance-btn-secondary" onclick="FinanceUI.simulateBankReturn()">📥 Importar Retorno Bancário (com Críticas)</button>
            <button class="finance-btn-secondary" onclick="FinanceUI.openCheckModal()">✍️ Emitir Cheque</button>
          </div>
        </div>

        <div class="finance-card">
          <div class="finance-card-title">
            <span>Conciliação Bancária OFX Automática</span>
            <button class="finance-btn-primary" onclick="FinanceUI.simulateOfxImport()">📥 Importar Extrato OFX</button>
          </div>
          <p style="font-size: 0.85rem; color: var(--ink-muted);">Leitura de arquivos OFX de qualquer banco com pareamento automático de datas e valores.</p>
          <div style="display: flex; gap: 0.5rem; margin-top: 1rem;">
            <button class="finance-btn-secondary" onclick="FinanceUI.runAutoReconcile()">⚡ Conciliar Automaticamente</button>
            <button class="finance-btn-secondary" onclick="FinanceUI.lockCalendar()">🔒 Bloquear Calendário do Mês</button>
          </div>
        </div>

        <div class="finance-card" style="grid-column: span 2;">
          <div class="finance-card-title">
            <span>Recursos Antecipados / Suprimento de Fundos</span>
            <button class="finance-btn-primary" onclick="FinanceUI.openAdvanceFundModal()">+ Conceder Adiantamento</button>
          </div>
          <table class="finance-table">
            <thead>
              <tr>
                <th>Protocolo</th>
                <th>Servidor Responsável</th>
                <th>Tipo</th>
                <th>Empenho</th>
                <th>Valor (R$)</th>
                <th>Vencimento</th>
                <th>Status</th>
                <th>Ações</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>SUP-202601001</td>
                <td>Carlos Eduardo da Silva</td>
                <td>Suprimento de Fundos</td>
                <td>2026/000210</td>
                <td>R$ 8.000,00</td>
                <td>30 dias</td>
                <td><span class="finance-badge finance-badge-warning">Aberto</span></td>
                <td><button class="finance-btn-secondary" onclick="FinanceUI.renderAccountability(1)">Prestar Contas</button></td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    `;
  },

  postRender: function() {
    if (this.currentTab === 'contabilidade') {
      this.loadJournalEntries();
    }
  },

  loadJournalEntries: function() {
    fetch('/api/finance/journal/query?exercise=2026')
      .then(r => r.json())
      .then(d => {
        const body = document.getElementById('finance-journal-body');
        if (!body) return;
        if (!d.records || d.records.length === 0) {
          body.innerHTML = `<tr><td colspan="8" style="text-align: center;">Nenhum lançamento no período.</td></tr>`;
          return;
        }
        body.innerHTML = d.records.map(r => `
          <tr>
            <td><strong>#${r.entry_number}</strong></td>
            <td>${r.entry_date}</td>
            <td>${r.fact_type}</td>
            <td><code>${r.debit_account}</code></td>
            <td><code>${r.credit_account}</code></td>
            <td><strong>R$ ${(r.amount_cents / 100).toLocaleString('pt-BR', {minimumFractionDigits: 2})}</strong></td>
            <td><span class="finance-badge finance-badge-info">${r.superavit_attribute === 'F' ? 'Financeiro' : 'Patrimonial'}</span></td>
            <td>
              ${r.is_reversal === 0
                ? `<button class="finance-btn-secondary" style="padding: 0.2rem 0.5rem; font-size: 0.8rem;" onclick="FinanceUI.reverseJournal(${r.id})">↩️ Estornar</button>`
                : `<span class="finance-badge finance-badge-danger">Estorno</span>`}
            </td>
          </tr>
        `).join('');
      })
      .catch(() => {
        const body = document.getElementById('finance-journal-body');
        if (body) body.innerHTML = `<tr><td colspan="8" style="text-align: center; color: red;">Erro ao carregar escrituração.</td></tr>`;
      });
  },

  openNewJournalModal: function() {
    const amt = prompt("Valor do lançamento contábil em Reais (ex: 15000):", "15000");
    if (!amt) return;
    const hist = prompt("Histórico do lançamento:", "Empenho ordinário de aquisição de insumos");
    if (!hist) return;

    fetch('/api/finance/journal/post', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({
        exercise: 2026,
        entry_date: '2026-01-10',
        fact_type: 'despesa_empenho',
        debit_account: '6.2.2.1.1.01.00',
        credit_account: '5.2.2.1.1.01.00',
        amount_cents: Math.round(parseFloat(amt) * 100),
        history_summary: hist,
        superavit_attribute: 'P'
      })
    })
    .then(r => r.json())
    .then(res => {
      alert("Lançamento escriturado com sucesso! Nº " + res.entry_number);
      FinanceUI.loadJournalEntries();
    })
    .catch(err => alert("Erro ao escriturar: " + err.message));
  },

  reverseJournal: function(id) {
    if (!confirm("Deseja estornar o lançamento #" + id + "? O sistema manterá o registro original inalterado.")) return;
    fetch('/api/finance/journal/reverse', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({entry_id: id, reason: "Estorno solicitado pelo operador"})
    })
    .then(r => r.json())
    .then(res => {
      alert("Estorno realizado com sucesso! Lançamento de estorno Nº " + res.reversal_number);
      FinanceUI.loadJournalEntries();
    });
  },

  viewReport: function(reportType) {
    fetch('/api/finance/dcasp/' + reportType)
      .then(r => r.json())
      .then(d => {
        alert("--- " + (d.title || reportType) + " ---\n\n" + JSON.stringify(d, null, 2));
      })
      .catch(err => alert("Erro ao carregar relatório: " + err.message));
  },

  viewLrf: function(kind, anexo) {
    fetch(`/api/finance/lrf/${kind}/${anexo}`)
      .then(r => r.json())
      .then(d => {
        alert(`--- LRF ${kind.toUpperCase()} Anexo ${anexo} ---\n\n` + JSON.stringify(d, null, 2));
      });
  },

  exportMscFile: function() {
    fetch('/api/finance/msc/generate?exercise=2026&month=1&format=XBRL')
      .then(r => r.json())
      .then(d => {
        alert("Matriz de Saldos Contábeis (MSC) gerada em formato XBRL com sucesso!\n\nPrimeiras linhas:\n" + d.content.substring(0, 300) + "…");
      });
  },

  transmitReinfEvent: function(evt) {
    fetch('/api/finance/reinf/events/transmit', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({event_type: evt, competence: '2026-01'})
    })
    .then(r => r.json())
    .then(d => {
      alert(`Evento ${evt} transmitido para o WebService da EFD-Reinf com sucesso!\nRecibo da RFB: ${d.receipt_number}`);
    });
  },

  runProjectionPreview: function() {
    const p = document.getElementById('proj-piece').value;
    const r = parseFloat(document.getElementById('proj-rate').value);
    fetch('/api/finance/budget/project', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({piece_type: p, percentage_rate: r})
    })
    .then(r => r.json())
    .then(d => {
      const el = document.getElementById('proj-results');
      el.innerHTML = `<strong>Simulação Concluída:</strong> ${d.total_items} itens recalculados com projeção de +${r}%. Visualização prévia aprovada.`;
    });
  },

  importLoaIntoPpa: function() {
    fetch('/api/finance/budget/import-loa', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({target_exercise: 2026, source_exercise: 2025})
    })
    .then(r => r.json())
    .then(d => {
      alert(`Importação concluída! ${d.imported_items} dotações e estimativas da LOA importadas para o PPA 2026-2029.`);
    });
  },

  generateDecree: function() {
    const num = document.getElementById('decree-num').value;
    const typ = document.getElementById('decree-type').value;
    const amt = parseFloat(document.getElementById('decree-amt').value);
    const just = document.getElementById('decree-just').value;

    fetch('/api/finance/budget/decrees', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({decree_number: num, decree_type: typ, amount_cents: Math.round(amt * 100), justification: just})
    })
    .then(r => r.json())
    .then(d => {
      alert("Decreto gerado e publicado com sucesso!\n\n" + d.document_text);
    });
  },

  generateObeBatch: function() {
    fetch('/api/finance/treasury/obe/generate', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({contract_id: 1, commitment_ids: [101, 102, 103], payment_method: 'OBE'})
    })
    .then(r => r.json())
    .then(d => {
      alert(`Ordem Bancária Eletrônica gerada com sucesso!\nNº da Ordem: ${d.order_number}\nValor Total: R$ ${d.total_amount.toLocaleString('pt-BR', {minimumFractionDigits: 2})}`);
    });
  },

  simulateBankReturn: function() {
    fetch('/api/finance/treasury/obe/return', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({order_id: 1, return_content: 'RETORNO BANCO DO BRASIL: 1 ITEM REJEICAO POR CONTA INVALIDA'})
    })
    .then(r => r.json())
    .then(d => {
      alert(`Retorno bancário processado!\nItens rejeitados estornados automaticamente: R$ ${d.rejected_amount.toLocaleString('pt-BR', {minimumFractionDigits: 2})}`);
    });
  },

  simulateOfxImport: function() {
    fetch('/api/finance/treasury/ofx/import', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({bank_account_id: '1182-7/25000-1', ofx_content: '<OFX>EXTRATO BANCARIO BB</OFX>'})
    })
    .then(r => r.json())
    .then(d => {
      alert(`Extrato OFX importado com sucesso!\n${d.imported_movements} movimentações lidas para conciliação.`);
    });
  },

  runAutoReconcile: function() {
    fetch('/api/finance/treasury/ofx/reconcile', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({reconciliation_id: 1})
    })
    .then(r => r.json())
    .then(d => {
      alert(`Conciliação Automática executada com sucesso! Todos os lançamentos bancários foram pareados.`);
    });
  },

  lockCalendar: function() {
    fetch('/api/finance/treasury/ofx/lock', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({exercise: 2026, month: 1, reason: 'Fechamento Contábil Mensal'})
    })
    .then(r => r.json())
    .then(d => {
      alert("Mês bloqueado com sucesso no calendário de conciliação!");
    });
  },

  exportManad: function() {
    fetch('/api/finance/exports/manad?exercise=2026&competence=2026-01')
      .then(r => r.json())
      .then(d => {
        alert("Arquivo MANAD da Previdência gerado com sucesso!\n\n" + d.content);
      });
  },

  exportSigfis: function() {
    fetch('/api/finance/exports/sigfis?exercise=2026&competence=01')
      .then(r => r.json())
      .then(d => {
        alert("Prestação de contas SIGFIS TCE-RJ gerada com sucesso!\n\n" + d.xml_batch);
      });
  },

  loadSiaficAuthModal: function() {
    const cpf = prompt("Informe o CPF para autenticação SIAFIC (Dec. 10.540/20):", "111.222.333-44");
    if (!cpf) return;
    fetch('/api/public/finance/siafic/auth', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({cpf: cpf, name: 'Operador Financeiro'})
    })
    .then(r => r.json())
    .then(d => {
      alert(`Usuário autenticado no SIAFIC com sucesso!\nNome: ${d.name}\nCPF: ${d.cpf}\nTermo de Responsabilidade: Assinado Digitalmente`);
    });
  }
};

// ── Interceptação da Página ERP para Finanças & Contabilidade ──
(function() {
  const originalErpPage = window.erpPage;
  window.erpPage = async function(module) {
    if (module === 'finance') {
      setTimeout(() => {
        const main = document.getElementById('main');
        if (main) FinanceUI.render(main);
      }, 50);
      return '<div class="loading-panel"><div class="loader"></div>Carregando Contabilidade, Finanças e Tesouraria...</div>';
    }
    return originalErpPage ? await originalErpPage(module) : '';
  };
})();

