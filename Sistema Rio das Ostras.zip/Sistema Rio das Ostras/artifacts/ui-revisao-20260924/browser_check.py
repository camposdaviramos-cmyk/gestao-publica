"""Navegação real em instalação temporária. A instalação 8080 só recebe GET público."""
import json
import sys
import tempfile
import threading
from pathlib import Path
from urllib.request import urlopen
from werkzeug.serving import make_server
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'artifacts/ui-revisao-20260924'
sys.path.insert(0, str(ROOT))
from app import create_app

result = {'routes': [], 'errors': [], 'console_errors': []}
try:
    with urlopen('http://127.0.0.1:8080/api/status', timeout=5) as response:
        result['active_public_status'] = json.load(response)
except Exception as exc:
    result['active_public_status'] = str(exc)

with tempfile.TemporaryDirectory(prefix='rio-audit-browser-') as td:
    app = create_app({'TESTING': True, 'DATA_DIR': td, 'DATABASE': str(Path(td) / 'audit.db')})
    with app.app_context():
        from finance_seed import seed_finance
        from people_seed import seed_people
        from social_seed import seed_social
        from control_seed import seed_control
        from bi_seed import seed_bi
        seed_finance(); seed_people(); seed_social(); seed_control(entity_id=1, exercise=2026); seed_bi()
    server = make_server('127.0.0.1', 0, app, threaded=True)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    base = f'http://127.0.0.1:{server.server_port}'
    try:
        with sync_playwright() as p:
            browser = p.chromium.launch()
            context = browser.new_context(viewport={'width': 1440, 'height': 1000})
            password = 'AuditoriaTemporaria2026!!'
            assert context.request.post(base + '/api/setup', data={'name': 'Auditoria temporária', 'email': 'audit@example.test', 'password': password}).status == 201
            assert context.request.post(base + '/api/login', data={'email': 'audit@example.test', 'password': password}).status == 200
            page = context.new_page()
            page.on('dialog',lambda dialog: dialog.dismiss())
            page.on('pageerror', lambda error: result['errors'].append(str(error)))
            page.on('console', lambda message: result['console_errors'].append(message.text) if message.type == 'error' else None)
            page.add_init_script("window.auditViolations=[];document.addEventListener('securitypolicyviolation',e=>window.auditViolations.push({directive:e.violatedDirective,blocked:e.blockedURI}));")
            for route in ['finance','control','people','social','bi']:
                page.goto(base + '/#/' + route)
                page.wait_for_selector('.module-workspace')
                page.wait_for_timeout(500)
                entry = {'route':route,'tabs':[]}
                tabs=page.locator(f'.{route}-tab-btn')
                for i in range(tabs.count()):
                    tabs.nth(i).click()
                    page.wait_for_timeout(500)
                    entry['tabs'].append({'name':tabs.nth(i).inner_text(),'active':tabs.nth(i).evaluate("e=>e.classList.contains('active')"),'inline':page.locator('[onclick],[onchange],[onkeyup],[onkeydown]').count()})
                tabs.nth(0).click()
                page.wait_for_timeout(300)
                page.screenshot(path=str(OUT/f'{route}-desktop.png'),full_page=True)
                page.set_viewport_size({'width':390,'height':844})
                page.wait_for_timeout(100)
                entry['mobile_width']=page.evaluate('({scroll:document.documentElement.scrollWidth,viewport:innerWidth})')
                page.screenshot(path=str(OUT/f'{route}-mobile.png'),full_page=True)
                page.set_viewport_size({'width':1440,'height':1000})
                page.evaluate("document.documentElement.dataset.theme='dark'")
                page.wait_for_timeout(350)
                page.screenshot(path=str(OUT/f'{route}-dark.png'),full_page=True)
                page.evaluate("document.documentElement.dataset.theme='light'")
                entry['csp']=page.evaluate('window.auditViolations')
                result['routes'].append(entry)
            result['flows']=[]
            def visit(route):
                page.goto(base + '/#/' + route)
                page.wait_for_selector('.module-workspace')
                page.wait_for_timeout(350)
            def close_modal():
                if page.locator('#modal[open]').count(): page.locator('#modal [data-action="close-modal"]').first.click()
            def fill_form(values):
                page.wait_for_selector('#module-editor')
                for name,value in values.items(): page.locator(f'#module-editor [name="{name}"]').fill(str(value))
            def submit(path):
                with page.expect_response(lambda r: path in r.url and r.request.method=='POST') as pending:
                    page.locator('#module-editor button[type=submit]').click()
                response=pending.value
                assert response.ok,(path,response.status,response.text())
                assert response.request.headers.get('x-csrf-token'),path
                page.wait_for_timeout(200)
                result['flows'].append({'path':path,'status':response.status,'csrf':True})
            visit('finance')
            page.get_by_role('button',name='+ Novo Lançamento',exact=True).click()
            fill_form({'exercise':2026,'entry_date':'2026-09-24','fact_type':'despesa_empenho','debit_account':'6.2.2.1.1.01.00','credit_account':'5.2.2.1.1.01.00','amount':'123.45','history_summary':'Verificação da interface','superavit_attribute':'P'})
            submit('/finance/journal/post')
            assert page.locator('#finance-journal-body').inner_text().find('123,45')>=0
            page.get_by_role('button',name='+ Novo Lançamento',exact=True).click()
            fill_form({'exercise':2026,'entry_date':'2026-09-24','fact_type':'despesa_empenho','debit_account':'INVALIDA','credit_account':'5.2.2.1.1.01.00','amount':'1','history_summary':'Teste de erro','superavit_attribute':'P'})
            page.locator('#module-editor button[type=submit]').click()
            page.wait_for_function("() => document.querySelector('#module-editor .form-error').textContent.length>0")
            result['validation_error']=page.locator('#module-editor .form-error').inner_text()
            close_modal()
            page.locator('.finance-tab-btn[data-tab="reinf"]').click()
            page.get_by_role('button',name='+ Registrar Nota Fiscal / RPS',exact=True).click()
            fill_form({'taxpayer_id':1,'creditor_document':'12345678000199','creditor_name':'Credor do teste','invoice_number':'UI-001','service_type_code':'100000001','gross':1000,'rate_percent':11})
            submit('/finance/reinf/invoices');close_modal()
            page.locator('.finance-tab-btn[data-tab="tesouraria"]').click()
            page.get_by_role('button',name='Emitir Cheque',exact=True).click()
            fill_form({'bank_account_code':'TESTE','check_number':901,'bearer_name':'Favorecido do teste','amount':'10.50'})
            submit('/finance/treasury/checks');close_modal()
            page.get_by_role('button',name='+ Conceder Adiantamento',exact=True).click()
            fill_form({'server_cpf':'52998224725','server_name':'Responsável UI','commitment_id':'UI-001','amount':'100','advance_type':'Suprimento_Fundos'})
            submit('/finance/treasury/advance-funds')
            page.get_by_role('button',name='Prestar Contas',exact=True).first.click()
            fill_form({'spent':80,'returned':20})
            submit('/finance/treasury/advance-funds/accountability')
            assert 'Prestado' in page.locator('#finance-advance-body').inner_text()
            visit('people')
            page.get_by_role('button',name='Detalhes',exact=True).first.click()
            page.wait_for_selector('#modal[open]');close_modal()
            page.get_by_role('button',name='Cópia de Registro',exact=True).click()
            fill_form({'source_employee_id':1,'new_registration':'UI-COPIA-01'})
            submit('/people/employees/copy')
            page.wait_for_function("() => document.querySelector('#people-tab-content').textContent.includes('UI-COPIA-01')")
            page.locator('.people-tab-btn[data-tab="portal"]').click()
            page.get_by_role('button',name='Atualizar Lista de Pendências',exact=True).click()
            page.wait_for_selector('#modal[open]');assert 'Nenhum registro' in page.locator('#modal').inner_text();close_modal()
            visit('social')
            page.get_by_role('button',name='Nova Família',exact=True).click()
            fill_form({'family_code':'UI-FAM-001','head_nis':'12345678901','head_name':'Família de teste <b>literal</b>','head_cpf':'52998224725','head_birth_date':'1980-01-01','address':'Rua do teste','neighborhood':'Centro','cras_unit_id':1,'total_income':100,'members_count':2})
            submit('/social/families')
            page.wait_for_function("() => document.querySelector('#social-tab-content').textContent.includes('Família de teste')")
            assert page.locator('#social-tab-content b').count()==0
            assert '<b>literal</b>' in page.locator('#social-tab-content').inner_text()
            page.locator('#social-family-search').fill('Família de teste');page.locator('#social-family-search').press('Enter');page.wait_for_timeout(200)
            page.get_by_role('button',name='Prontuário',exact=True).first.click();page.wait_for_timeout(200)
            assert page.locator('#social-family-drawer').is_visible()
            page.locator('#social-family-drawer').get_by_role('button',name='Fechar',exact=True).click()
            page.locator('.social-tab-btn[data-tab="acolhimento"]').click()
            page.get_by_role('button',name='Admissão em Acolhimento',exact=True).click()
            fill_form({'unit_id':6,'resident_name':'Residente UI','reason':'Teste de acolhimento','responsible_technician':'Técnico UI'})
            submit('/social/shelterings')
            row=page.locator('tr').filter(has_text='Residente UI')
            row.get_by_role('button',name='Desligar',exact=True).click()
            fill_form({'discharge_date':'2026-09-24','discharge_reason':'Reintegração familiar'})
            submit('/discharge')
            visit('control')
            page.locator('.control-tab-btn[data-tab="plans"]').click()
            page.get_by_role('button',name='Novo Plano de Ação',exact=True).click()
            for key,value in {'ap-ref':'UI-001','ap-title':'Plano de teste UI','ap-fact':'Fato de teste','ap-cause':'Causa de teste','ap-action':'Correção de teste','ap-resp':'Responsável','ap-email':'responsavel@example.test','ap-deadline':'2026-12-01'}.items(): page.locator('#'+key).fill(value)
            with page.expect_response(lambda r: '/control/action-plans' in r.url and r.request.method=='POST') as response:
                page.locator('#action-plan-form button[type=submit]').click()
            assert response.value.ok,response.value.text()
            result['flows'].append({'path':'/control/action-plans','status':response.value.status,'csrf':bool(response.value.request.headers.get('x-csrf-token'))})
            visit('bi')
            page.get_by_role('button',name='Compartilhar',exact=True).click()
            page.wait_for_selector('#bi-share-link')
            shared=page.locator('#bi-share-link').input_value();assert context.request.get(shared).ok;close_modal()
            page.locator('.bi-tab-btn[data-tab="assistant"]').click()
            page.locator('#bi-assistant-query').fill('Qual o gasto com pessoal?')
            with page.expect_response(lambda r: '/bi/assistant/query' in r.url) as response:page.locator('#bi-assistant-query').press('Enter')
            assert response.value.ok
            page.wait_for_timeout(200)
            assert 'Resposta' in page.locator('#bi-assistant-response').inner_text()
            page.get_by_role('button',name='Modo TV Kiosk',exact=True).click()
            page.wait_for_selector('#bi-kiosk-content .bi-card')
            page.keyboard.press('Escape');assert page.locator('#bi-kiosk-view').count()==0
            result['flows'].append({'path':'BI: compartilhamento, assistente por Enter e modo TV','status':'ok'})
            page.goto(base + '/#/annex')
            page.wait_for_selector('.erp-requirement')
            assert page.evaluate('annexState.items.length')==1314
            assert page.locator('#annex-remediation tbody tr').count()==5
            assert page.evaluate("annexStats([{status:'Parcial'},{status:'Implementado'},{status:'Não comprovado'}]).pct")==33.3
            assert page.evaluate("annexStats([{status:'Não comprovado'}]).unverified")==1
            assert '50% Parcial' not in page.locator('#main').inner_text()
            result['annex_items']=1314
            page.locator('#erp-annex-search').fill('AUD-002')
            page.wait_for_timeout(150)
            page.screenshot(path=str(OUT/'annex-progress.png'),full_page=True)
            result['final_csp']=page.evaluate('window.auditViolations')
            assert not result['errors'],result['errors']
            assert not result['final_csp'],result['final_csp']
            browser.close()
    finally:
        server.shutdown()
(OUT / 'browser.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(result, ensure_ascii=False, indent=2))
