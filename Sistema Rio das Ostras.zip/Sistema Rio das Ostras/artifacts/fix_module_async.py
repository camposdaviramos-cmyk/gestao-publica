﻿from pathlib import Path
import re
p=Path('static/social-ui.js');s=p.read_text(encoding='utf-8');s=re.sub(r'  postRender: function\(\) \{.*?^  \},', '''  postRender: async function() {
    const loaders={familias:['loadFamilies','loadFamilyMetrics'],rma:['loadRma'],beneficios:['loadSupplies','loadBenefits'],acolhimento:['loadShelterings'],habitacao:['loadComplexes'],mrosc:['loadOscs','loadOscContracts'],territorios:['loadHeatmap','loadTerritories']};
    try { await Promise.all((loaders[this.currentTab] || []).map(name => this[name]())); }
    catch(error) { toast(error.message,true); }
  },''',s,count=1,flags=re.S|re.M)
s=s.replace('      this.postRender();\n    }','    }').replace("btn.dataset.tab === tabName);\n    });\n  },", "btn.dataset.tab === tabName);\n    });\n    return this.postRender();\n  },",1).replace('    this.switchTab(this.currentTab);','    return this.switchTab(this.currentTab);').replace('    this.loadFamilies(q);','    return this.loadFamilies(q);')
s=re.sub(r'\n{4,}','\n\n',s);p.write_text(s,encoding='utf-8')
p=Path('static/finance-ui.js');s=p.read_text(encoding='utf-8');s=s.replace('      this.postRender();\n    }','    }').replace("btn.dataset.tab === tabName);\n    });\n  },", "btn.dataset.tab === tabName);\n    });\n    return this.postRender();\n  },",1)
s=s.replace("    this.switchTab(this.currentTab);\n    if (window.toast) window.toast('Dados do módulo financeiro atualizados.');",'    return this.switchTab(this.currentTab);')
p.write_text(s,encoding='utf-8')
p=Path('static/bi-ui.js');s=p.read_text(encoding='utf-8');s=s.replace('    this.loadCurrentTab();','    return this.loadCurrentTab();').replace('      this.askAssistant();','      return this.askAssistant();')
start=s.index('  loadCurrentTab: function()');end=s.index('\n  // ===',start)
part=s[start:end].replace('loadCurrentTab: function()','loadCurrentTab: async function()').replace("    if (this.currentTab", "    try {\n    if (this.currentTab",1)
part=re.sub(r"(\) )this\.(render\w+\(content\));",r'\1return await this.\2;',part)
part=part.replace('\n  },','\n    } catch(error) { content.innerHTML=`<div class="notice">${ModulesUI.escape(error.message)}</div>`; }\n  },')
s=s[:start]+part+s[end:];s=re.sub(r'\n{4,}','\n\n',s);p.write_text(s,encoding='utf-8')
p=Path('static/people-ui.js');s=p.read_text(encoding='utf-8');s=re.sub(r"(if \(tabName === '[^']+'\) )(render\w+\(container\))",r'\1return \2',s);p.write_text(s,encoding='utf-8')
p=Path('static/control-ui.js');s=p.read_text(encoding='utf-8')
for value in ["refId||''","defaultTitle||''"]:s=s.replace('${'+value+'}', '${esc('+value+')}')
p.write_text(s,encoding='utf-8')
